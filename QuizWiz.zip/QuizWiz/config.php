<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
<?php
/*define("host","localhost");
define("user","quiz_master");
define("pass","Ch@y@n");
define("db","quizwiz");
*/
$host="localhost";
$user="root";
$pass="";
$db="quizwiz";

$conn=mysqli_connect($host,$user,$pass,$db);
if(mysqli_connect_errno()){
    echo("Connection to database failed with error: ".mysqli_connect_errno());
}

?>