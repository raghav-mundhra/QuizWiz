-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2017 at 10:27 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quizwiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `college_questions`
--

CREATE TABLE `college_questions` (
  `ques_id` int(11) NOT NULL,
  `question` varchar(1000) NOT NULL,
  `option1` varchar(1000) NOT NULL,
  `option2` varchar(1000) NOT NULL,
  `option3` varchar(1000) NOT NULL,
  `option4` varchar(1000) NOT NULL,
  `correct_opt` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college_questions`
--

INSERT INTO `college_questions` (`ques_id`, `question`, `option1`, `option2`, `option3`, `option4`, `correct_opt`) VALUES
(1, 'Who is the present RBI Governor ?', 'Raghuram Rajan', 'Urijit Patel', 'D Subbarao', 'N Damodaran', 2),
(2, 'Which consulting major has a networking platform called D-Street?', 'KPMG', 'Deloitte', 'Capgemini', 'BCG', 2),
(3, 'Which entertainment company publishes an annual report called \'KIDSENSE\'?', 'Bloomberg', 'Sony', 'Disney', 'CNBC', 3),
(4, 'Interpret the world        is the tagline of which magazine?', 'The Economist', 'TIME', 'Business world', 'Fortune', 1),
(5, 'Which US company began its Indian operations in 1928, closed down in 1959 and returned in 1994 with a JV with CK Birla group?', 'General Motors', 'Ford', 'Fiat', 'Skoda', 1),
(6, 'Which management guru severed in the United States Navy, worked in White House and authored "Reimagine!\nBusiness Excellence in a Disruptive Age" ?', 'Michael Porter', 'Paul krugman', 'Chris Andersen', 'Tom Peters', 4),
(7, 'He argued           If people take full accountability of taxes, they can reduce the burden of government.     \nRonald Reagen was greatly inspired by this economist. Identify?', 'Adam Smith ', 'Amartya Sen', 'Ben Bernake', 'David Ricardo', 4),
(8, 'What are the 4 P\'s of marketing:  Product, Price, Promotion, Place collectively known as?', 'BCG Matrix', 'Marketing Mix', 'Brand Mix', 'Product Mktg', 2),
(9, 'The Body Shop:    book written by', 'Anita Roddick', 'Coco chanel', 'Ralph lauren', 'Versace', 1),
(10, 'Which company owns currently the trademark "Eau De Cologne"?', 'Unilever', 'Walmart', 'Procter and Gamble', 'Nivea', 3),
(11, 'Jean-Baptiste Say coined which word first in about 1800 meaning "one who undertakes an enterprise"?', 'Businessmen', 'Entrepreneur', 'Enterpiser', 'Professional', 2),
(12, 'What technique did Albert Humphrey pioneer at Stanford\nUniversity in the 1960s using data from Fortune 500 companies?', 'Cost benefit Analysis', 'SWOT Analysis', 'Demand supply analysis', 'Breakeven Analysis', 2),
(13, 'What is the name given to an employee who quits a company to take up a job with another\ncompany, but rejoins his previous company?', 'Bloomberg', 'Annihiliator', 'Insider', 'Boomerang', 4),
(14, 'The sticks were made of polished hazel or willow wood, and transactions were recorded by notches carved into the square with a knife. The size of the notch indicated the denomination.\nName of which Software Company is derived from the name of the stick?', 'Cisco', 'Oracle', 'Tally', 'Infosys', 3),
(15, 'The credit for popularising which term is given to Arnold Toynbee, whose lectures given in 1881\ngave a detailed account of it?', 'Black Friday', 'Industrial Revolution', 'Kaizen', 'Mass production', 2),
(16, 'What did William Ramsay create which is now popularly used as an advertising tool?', 'Billboard', 'Printer', 'Neon Glow Sign Board', 'Simulator', 3),
(17, 'In food and FMCG category marketing, what is LUP?', 'Low Unit Packaging', 'Last Unit Packaging', 'Low Used Packaging', 'Last Used Packaging', 1),
(18, 'Sameer Gehlaut, IIT D graduate, is the founder and chairman of which online trading firm?', 'India infoline', 'Edelweiss', 'JMF', 'India Bulls', 4),
(19, 'Which management guru explained Synergy as 2+2 = 5?', 'David ogilvy', 'Igor Ansoff', 'Adam Smith', 'C K Prahlad', 2),
(20, 'Complete the quote by Ted Turner,      Early to bed, early to rise : work like hell and _______', 'Promote', 'Digitalise', 'Sleep', 'Advertise', 4),
(21, 'FEMA (in India) stands for', 'Foreign Exchange Management Act', 'Funds Exchange Management Act', 'Finance Enhancement Monetary Act', 'Future Exchange Management Act', 1),
(22, 'Henry Fayol is known for which management theory', 'Scientific Management', 'Rationalisation', 'Industrial Psychology', 'Principles of Management', 4),
(23, 'Which e-commerce company has become a member of the self-regulatory voluntary organization Advertising Standards Council of India (ASCI) from April, 2017?', 'MobiKwik', 'FreeCharge', 'Paytm', 'PhonePe', 3),
(24, 'Which bank has launched a unique card \'Unnati\' targeted at including Jan Dhan account-holders across the country?', 'Punjab National Bank', 'State Bank of India', 'Canara Bank', 'Oriental Bank of Commerce', 2),
(25, 'Who was the first Indian to become the RBI governor?', 'C D Deshmukh', 'S Radhkrishnan', 'Morarji Desai', 'D Subbarao', 1),
(26, 'By what name is the building \'Phiroze Jeejebhoy Towers\' better known as?', 'NSE', 'BSE', 'SEBI', 'RBI', 2),
(27, 'For which area of Economics was Richard Thaler awarded Nobel prize?', 'Classical Economics', 'Market Socialism', 'Behavioral Economics', 'Marxism', 3),
(28, 'The Factor theory was propounded  by  :', 'Fredrick Hertzberg', 'David McClellanel', 'Mc Cardhy', 'Philip Kotler ', 1),
(29, 'In 1882 American express started its expansion in the area of financial services by launching which service to compete with the United States Post Office?', 'Credit card', 'Money Orders', 'CoD', 'Paypal', 2),
(30, 'Marketing through mouth is called Word of Mouth. What is marketing through SMS called?', 'Word of message', 'Word of shorthand', 'Word of text', 'Word of service', 3),
(31, 'What is derived from the collective word of Ferrets ? ', 'Business', 'Industry', 'Building', 'Oven', 1),
(32, 'Which word originated in the business parlance from meeting of businessmen in Willard Hotel, New York?', 'Bribing', 'Uplifting', 'Cementing', 'Lobbying', 4),
(33, 'What does NIR stand for? It is a new concept of investement from Japan. ', 'No interest Rate', 'Nine Interest Rate', 'Negative Interest Rate', 'Nil Interest Rate', 3),
(34, 'The key methods include Ranking, Classifications, Point band Factor Comparison. What evaluation are we talking about.', 'Performance Appraisal', 'Job evaluation', 'Ethical analysis', 'Error Reporting', 1),
(35, '\n_______ investments are subject to market risk. Please read the offer document carefully before investing. FITB', 'Stock', 'Mutual Fund', 'Share', 'Insurance', 2),
(36, 'The process by which an underwriter attempts to determine at what price to offer an IPO based on demand from Institutional investors.', 'Private Placement', 'Market pricing', 'Fixed pricing', 'Book Building', 4),
(37, 'TSEC is a Tata Venture. What does SE stand for?', 'System Enterprise', 'Social Enterprise', 'Social Entrepreneurship', 'System Entrepreneurship', 3),
(38, 'What one word term means           a period of temporary economic decline during which trade and industrial activity are reduced, generally identified by a fall in GDP in two successive quarters?', 'Galloping', 'Recession', 'Havoc', 'Compression', 2),
(39, 'Named after a waterbody, _________ Strategy is referred to a market of a product where there is a little or no competition.', 'White ocean', 'Green ocean', 'Blue ocean', 'Clean ocean', 3),
(40, 'An  ________ investor is an affluent individual who provides capital for a business startup, usually in exchange for convertible debts or ownership equity. The term originally comes from Broadway theatre, where such persons were referred to as ______  without whom many productions would have shut down. ', 'Angel Investor', 'VIP', 'Seed Investor', 'First Investor', 1),
(41, 'This type of loan is a short term loan used until a person or company secures permanent financing or removes an existing obligation. Also known as swing loans. ', 'Mortgage Loans', 'Exchange Loans', 'Term loans', 'Bridge Loans', 4),
(42, 'What code named as    HD    was produced at a facility in Mysore in November 2016?', 'Hard Disk', 'High Definiton Notes', 'High Denomination Notes', 'High Dated Notes', 3),
(43, 'What is Karoshi in Japanese corporate culture?', 'Death by rest', 'Death by Stress', 'Death by no work', 'Death by Overwork', 4),
(44, 'Trademarked in the UK, what generic material was named after John L McAdam, a British surveyor who suggested that the broken stones of even size mixed with tar would result in highest quality products?', 'Glass', 'Tarmac', 'Marble', 'Plywood', 2),
(45, '2 word term used to denote bias shown by customers for certain products due to favourable expericence of other products of same manufacturer.', 'Hello effect', 'Hi effect', 'High effect', 'Halo Effect', 4),
(46, 'In 2015, Union Budget what scheme announced by the Finance Minister in the honour of former PM Atal Behari Vajpayee?', 'Pension', 'Insurance', 'Senior citizen', 'Provident fund', 1),
(47, 'What was marketed as "Bigger Than Bigger"?', 'Iphone 7', 'Iphone x', 'Iphone 6 ', 'Iphone 8', 3),
(48, 'This is a cognitive bias in which consumers place a disproportionately high value on products they partially created. Whai is it called?', 'Halo effect', 'IKEA Effect', 'Kite effect', 'Nivea effect', 2),
(49, ' It is the rate at which the central bank of a country lends money to commercial banks in the event of any shorfall of funds. ', 'CRR', 'SLR', 'Credit Rate', 'Repo Rate', 4),
(50, '   Who is the Vice Chairman of  Niti  Aayog  ?', 'Narendra Modi', 'Deepak Parekh', 'Arun Jaitley', 'Rajiv Kumar', 4),
(51, 'Which channel has bagged the global media rights for IPL  for next 5 years', 'Star', 'ESPN', 'SONY', 'SKY', 1),
(52, 'Which city was home to the maximum number of shell companies recently banned by SEBI?', 'Mumbai ', 'Chennai', 'Kolkata', 'Delhi', 3),
(53, '\nWho owns the  e-marketplace   eBay.in  ?', 'Flipkart', 'Alibaba', 'Google', 'Snapdeal', 1),
(54, '\nWhich govt owned institution compiles the Housing Price Index popularly known as Residex ?', 'NABARD', 'NHAI', 'NHB', 'SHB', 3),
(55, '\nAsia\'s largest musical festival \'SUNBURN\' is organized by which agency?', 'Taproot', 'Madison World', 'Scarecrow', 'Percept', 4),
(56, 'In early 1980\'s Salman Khan appeared as a model for which soft drink commercial?', 'Campa Cola', 'LImca', 'Gold Spot', 'PAM Cola', 3),
(57, '\nWhich Indian film has become the biggest grosser in China among non-Hollywood films', 'Sivaji', 'Dangal', 'Bahubali', 'Robot', 2),
(58, 'Taking India to the world      is the slogan of which business group?', 'Reliance', 'Tata', 'M&M', 'Aditya Birla Group', 4),
(59, 'Which radio station gives Kaan awards in the field of advertising?', 'Red FM', 'Radio Mirchi', 'Radio City', 'Radio One', 2),
(60, 'The    We miss you too    campaign was launched by which company?', 'Complan', 'Maggi', 'Rasana', 'Boost', 2),
(61, '\nWhat is the name of the lifestyle brand where cricketer MS Dhoni has a stake?', 'FIVE', 'SIX ', 'SEVEN', 'EIGHT', 3),
(62, 'Blue Ribbon     was the initial name of which sports goods manufacturing company?', 'Nike', 'Adidas', 'Puma', 'Lotto', 1),
(63, 'The Pro Kabaddi team Bengal Warriors is owned by?', 'Veera Sports', 'Unilazer Sports', 'Future Group', 'Abhishek Bachchan', 3),
(64, 'Sportsworld is a defunct Indian sports magazine that was publish by which group?', 'The Times Group', 'Living Media', 'The Hindu', 'Ananda Bazar Group', 3),
(65, '\nWho has launched apparel brand WROGN?', 'Virat Kohli', 'Rohit Sharma', 'Suresh Raina', 'M S Dhoni', 1),
(66, '\'Your home of sport\' is the slogan of which group of sports television channels?', 'Zee Sports', 'Channel 9', 'Sky Sports', 'Ten Sports', 3),
(67, '\nName the company which owns the new Pune IPL team?', 'Rendezvous', 'RPG', 'Dabur', 'Sahara', 2),
(68, '\nWhich sports wear brand from the swimming industry uses a ÔboomrangÕ as its logo?', 'John Lewis ', 'TYR', 'Nashua', 'Speedo', 4),
(69, 'The TOI Story       is the book about which company?', 'The Hindu', 'Free Press Journal', 'Times of India', 'Deccan Chronicle', 3),
(70, 'Who is the author of the book \'Connect The Dots\'?', 'Durjoy Datta ', 'Chetan Bhagat', 'Amish Tripathi', 'Rashmi Bansal ', 4),
(71, 'The Accidental Prime Minister is a book by Sanjay Baru. It is about which Indian Prime Minister?', 'IK Gujaral', 'Manamohan Singh', 'Morarji Desai', 'P V Narasimha Rao', 2),
(72, '\nWhich famous media personality wrote the book\'2014The Election that Changed IndiaÕ?', 'Shekar Gupta ', 'Rajdeep Sardesai', 'Arnab Goswami', 'Barkha Dutt', 2),
(73, 'Ace Against the Odds       is an autobiography of which Indian sportsperson?', 'Sania Mirza', 'Sania Nehwal', 'PT Usha', 'Jwala Gutta', 1),
(74, 'Beyond Boundaries     is the autobiography of which industrialist of Indian Origin?', 'Lord Swaraj Paul', 'Lakshmi Mittal ', 'OP JIndal', 'Shiv Nadar', 1),
(75, 'Identify this motivational speaker and author of ÔYou Can WinÕ', 'Shiv Khera', 'Sandeep Maheshwari', 'Ujjwal Patni', 'Robin Sharma', 1),
(76, '\nWhich brand was first introduced by Ferrero in 1969 under the name ÔRefreshing MintsÕ?', 'Polo', 'Tic Tac', 'Altoids', 'Pez', 2),
(77, '\nThe word \'Fridge\' became popular thanks to which brand?', 'Maytag', 'Electrolux', 'Frigidaire', 'Kelvinator', 3),
(78, '\nWhich brand gets its name from a flower?', 'Crocin', 'Cherry Blossom', 'Liril', 'Kiwi', 2),
(79, '\nWhich Indian management guru is associated with the term Satisfactory Underperformance?', 'Rajat Gupta', 'Sumantra Ghoshal', 'CK Prahalad', 'Ram Charan', 2),
(80, '\nWhich was the first soft drink to be consumed in outer space?', 'Coca Cola', 'Pepsi', 'Sprite', 'Mountain Dew', 1),
(81, '\nThe first color TV in India was produced by which company?', 'Thomson', 'Onida', 'Videocon', 'Bosch', 3),
(82, '\nWhich college was earlier known as `Thomason College of Civil Engineering`?', 'IIM Ahmedabad', 'IIT Kharagpur', 'IIT Roorkee', 'IIT D', 3),
(83, '\nWho was independent India`s first railway minister?', 'John Mathai', 'BR Ambedkar', 'Amrit Kaur', 'RKS Chetty', 1),
(84, '\nIn 2016 which Indian state introduced Fat Tax on junk food?', 'Haryana', 'Gujarat', 'Kerela', 'Tamil Nadu', 3),
(85, '\nWhere did the British East India Company establish its first factory in South India?', 'Kakinada', 'Machilipatnam', 'Madras', 'Vizag', 2),
(86, '\nThe famous bird`s nest logo is associated with which FMCG group?', 'Nestle', 'Cadbury', 'Kraft Foods', 'Danone', 1),
(87, '\nWho owns the brand `Dettol`?', 'J&J', 'SC Johnson', 'Henkel', 'Reckitt Benckiser', 4),
(88, '\nWhat does Amul sell under its brand name    EPIC?', 'Ice Cream', 'Milk', 'Butter ', 'Ghee', 1),
(89, 'Which brand of corn puffs developed and produced by PepsiCo India gets its name from the Hindi word for      crunchy?', 'Bingo', 'Kurkure', 'Munchos', 'Cheetos', 2),
(90, '\nAir Sahara bough by Jet Airlines was rebranded as?', 'JetKonnect', 'Jetlite', 'Jet Blue', 'Blue Jet', 2),
(91, '\nTrust Pink Forget Stains      is the tagline of which product?', 'Surf Excel', 'Vanish', 'Tide', 'Revive', 2),
(92, 'Which was the first Indian movie of which Singapore Airlines bought rights to broadcast it in its aircraft?', 'Dabangg', '3 Idiots', 'My Name is Khan', 'Sivaji', 4),
(93, 'Which sportswear has announced mass manufacture of sports shoes using 3 D printing?', 'Nike', 'Adidas', 'Puma', 'Reebok', 2),
(94, 'Who owns PERPLE PEBBLE Pictures?', 'Rani mukerjee', 'Parineeti Chopra', 'RiyaSen', 'Priyanka Chopra', 4),
(95, 'Which was the last state to implement GST?', 'J&K', 'MP', 'UP', 'Gujarat', 1),
(96, 'Who is the CEO of HDFC ltd.?', 'Deepak Parekh ', 'Aditya Goyal', 'Aditya Puri', 'P Ghosh', 3),
(97, 'Under what brand name has Adidas launched the footwear for parathletes ?', 'Odds', 'Evens', 'Equals', 'Fine', 1),
(98, 'JIVA is a Spa brand of which Hotel group?\r\n', 'Oberoi', 'ITC', 'TAJ', 'Marriot', 3),
(99, 'What is Airport code of INDORE?', 'INR', 'IDR', 'IND', 'INO', 2),
(100, 'Hello 6E is magazine of which airline?', 'JetKonnect', 'Air india', 'Go air', 'Indigo', 4);

-- --------------------------------------------------------

--
-- Stand-in structure for view `final_db`
-- (See below for the actual view)
--
CREATE TABLE `final_db` (
`email_id` varchar(30)
,`score` int(2)
,`attempt_flag` tinyint(1)
,`reg_id` int(6)
,`name` varchar(30)
,`dob` date
,`gender` text
,`father_name` varchar(30)
,`phone_no` varchar(11)
,`address` varchar(200)
,`city` varchar(20)
,`pincode` int(6)
,`standard` int(2)
,`stream` varchar(12)
,`name_of_institution` varchar(100)
,`college_flag` tinyint(1)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `final_db2`
-- (See below for the actual view)
--
CREATE TABLE `final_db2` (
`email_id` varchar(30)
,`score` int(2)
,`attempt_flag` tinyint(1)
,`reg_id` int(6)
,`name` varchar(30)
,`dob` date
,`gender` text
,`father_name` varchar(30)
,`phone_no` varchar(11)
,`address` varchar(200)
,`city` varchar(20)
,`pincode` int(6)
,`standard` int(2)
,`stream` varchar(12)
,`name_of_institution` varchar(100)
,`college_flag` tinyint(1)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `new_attempts`
-- (See below for the actual view)
--
CREATE TABLE `new_attempts` (
`email_id` varchar(30)
,`score` int(2)
,`attempt_flag` tinyint(1)
,`reg_id` int(6)
,`name` varchar(30)
,`dob` date
,`gender` text
,`father_name` varchar(30)
,`phone_no` varchar(11)
,`address` varchar(200)
,`city` varchar(20)
,`pincode` int(6)
,`standard` int(2)
,`stream` varchar(12)
,`name_of_institution` varchar(100)
,`college_flag` tinyint(1)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `reg_email`
-- (See below for the actual view)
--
CREATE TABLE `reg_email` (
`email_id` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `school_questions`
--

CREATE TABLE `school_questions` (
  `ques_id` int(11) NOT NULL,
  `question` varchar(1000) NOT NULL,
  `option1` varchar(1000) NOT NULL,
  `option2` varchar(1000) NOT NULL,
  `option3` varchar(1000) NOT NULL,
  `option4` varchar(1000) NOT NULL,
  `correct_opt` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_questions`
--

INSERT INTO `school_questions` (`ques_id`, `question`, `option1`, `option2`, `option3`, `option4`, `correct_opt`) VALUES
(1, 'How do we better know octothorpe?', 'Tilde', 'Hashtag', 'Space', 'Backslash', 2),
(2, 'Which was the first country in which Facebook rolled out internet org?', 'Zambia', 'Zaire', 'Zimbabwe', 'Libya', 1),
(3, 'Which programming language named after a reptile species was created by Guido Van Rossum?', 'Turtle', 'Viper', 'Cobra', 'Python', 4),
(4, 'Kumon website teaches which subject?', 'Mathematics', 'Chemistry', 'English', 'Physics', 1),
(5, 'Which was the first bank in India to be owned and managed by Indians?', 'Punjab National Bank', 'Canara Bank', 'Indian Bank', 'Allahabad Bank', 1),
(6, 'ASIMO is the first humanoid robot to start the 2002 NYSE trading session. Which company produces the robot?', 'Toyota', 'Volkswagen', 'Lomborghini', 'Honda Motors', 4),
(7, 'Reva Electric Car Company was bought in May 2010 by which company making its entry in 50 most innovative company in 2013 by Fast company?', 'Mahindra', 'Eicher', 'Volkswagen', 'TataMotors', 1),
(8, 'Asia`s largest musical festival       SUNBURN       is organized by which agency?', 'Taproot', 'Madison World', 'Scarecrow', 'Percept', 4),
(9, 'In early 1980`s Salman Khan appeared as a model for which soft drink commercial?', 'Campa Cola', 'LImca', 'Gold Spot', 'PAM Cola', 3),
(10, 'Which famous singer sang the original lifebuoy jingle ÔLifebuoy hai jahaa tandurusti hai wahaanÕ?', 'Jagjit Singh', 'Pankaj Udhas', 'Kumar Sanu', 'Udit Narayan', 1),
(11, 'Taking India to the world      is the slogan of which business group?', 'Aditya Birla Group', 'Tata', 'Reliance', 'M&M', 1),
(12, 'Which radio station gives     Kaan     awards in the field of advertising?', 'Red FM', 'Radio Mirchi', 'Radio City', 'Radio One', 2),
(13, 'The     we miss you too     campaign was launched by which company?', 'Complan', 'Maggi', 'Rasana', 'Boost', 2),
(14, 'Which British magazine reports on the business and financial aspects of sports across the world?', 'Sports Star', 'Sports World', 'SportsPro', 'Top Gear', 3),
(15, 'Blue Ribbon      was the initial name of which sports goods manufacturing company?', 'Nike', 'Adidas', 'Puma', 'Lotto', 1),
(16, 'The Pro Kabaddi team Bengal Warriors is owned by?', 'Veera Sports', 'Unilazer Sports', 'Future Group', 'Abhishek Bachchan', 3),
(17, 'Sportsworld is a defunct Indian sports magazine that was publish by which group?', 'The Times Group', 'Living Media', 'The Hindu', 'Ananda Bazar Group', 3),
(18, 'Which cricketer has launched apparel brand WROGN?', 'Virat Kohli', 'Rohit Sharma', 'Suresh Raina', 'M S Dhoni', 1),
(19, 'Your home of sport      is the slogan of which group of sports television channels?', 'Zee Sports', 'Channel 9', 'Sky Sports', 'Ten Sports', 3),
(20, 'Name the group which owns the new Pune IPL team?', 'Rendezvous', 'RPG', 'Dabur', 'Sahara', 2),
(21, 'Which sports wear brand from the swimming industry uses a ÔboomrangÕ as its logo?', 'John Lewis', 'TYR', 'Nashua', 'Speedo', 4),
(22, 'The  TOI  Story      is a  book about which company ?', 'The Hindu', 'Free Press Journal', 'Times of India', 'Deccan Chronicle', 3),
(23, 'Who is the author of the book     Connect The Dots?', 'Durjoy Datta', 'Chetan Bhagat', 'Amish Tripathi', 'Rashmi Bansal', 4),
(24, 'The Accidental Prime Minister      is a book by Sanjay Baru. It is about which Indian Prime Minister?', 'IK Gujaral', 'Manamohan Singh', 'Morarji Desai', 'P V Narasimha Rao', 2),
(25, 'Which famous media personality wrote the book    2014The Election that Changed India?', 'Shekar Gupta ', 'Rajdeep Sardesai', 'Arnab Goswami', 'Barkha Dutt', 2),
(26, 'Ace Against the Odds     is an autobiography of which Indian sportsperson?', 'Sania Mirza', 'Sania Nehwal', 'PT Usha', 'Jwala Gutta', 1),
(27, 'Beyond Boundaries     is the autobiography of which industrialist of Indian Origin?', 'Lord Swaraj Paul', 'Lakshmi Mittal ', 'OP JIndal', 'Shiv Nadar', 1),
(28, 'Identify the motivational speaker and author of     You Can Win', 'Shiv Khera', 'Sandeep Maheshwari', 'Ujjwal Patni', 'Robin Sharma', 1),
(29, 'Which brand was first introduced by Ferrero in 1969 under the name:  Refreshing Mints?', 'Polo', 'Tic Tac', 'Altoids', 'Pez', 2),
(30, 'The word :Fridge: became popular thanks to which brand?', 'Maytag', 'Electrolux', 'Frigidaire', 'Kelvinator', 3),
(31, 'Which brand gets its name from a name of a flower?', 'Crocin', 'Cherry Blossom', 'Liril', 'Kiwi', 2),
(32, 'Which Indian management guru is associated with the term Satisfactory Underperformance?', 'Rajat Gupta', 'Sumantra Ghoshal', 'CK Prahalad', 'Ram Charan', 2),
(33, '\nWhich was the first soft drink to be consumed in outer space?', 'Coca Cola', 'Pepsi', 'Sprite', 'Mountain Dew', 1),
(34, '\nThe first color TV in India was produced by which company?', 'Thomson', 'Onida', 'Videocon', 'Bosch', 3),
(35, 'Which college was earlier known as   Thomason College of Civil Engineering?', 'IIM Ahmedabad', 'IIT Kharagpur', 'IIT Roorkee', 'IIT D', 3),
(36, '\nWho was independent India`s first railway minister?', 'John Mathai', 'BR Ambedkar', 'Amrit Kaur', 'RKS Chetty', 1),
(37, '\nIn 2016 which Indian state introduced Fat Tax on junk food?', 'Haryana', 'Gujarat', 'Kerela', 'Tamil Nadu', 3),
(38, '\nWhere did the British East India Company establish its first factory in South India?', 'Kakinada', 'Machilipatnam', 'Madras', 'Vizag', 2),
(39, '\nThe famous bird`s nest logo is associated with which FMCG group?', 'Nestle', 'Cadbury', 'Kraft Foods', 'Danone', 1),
(40, '\nWho owns the brand    Dettol?', 'J&J', 'SC Johnson', 'Henkel', 'Reckitt Benckiser', 4),
(41, '\nWhat does Amul  sell under  its  brand name    EPIC ?', 'Ice Cream', 'Milk', 'Butter ', 'Ghee', 1),
(42, '\nWhich brand of corn puffs developed and produced by PepsiCo India gets its name from the Hindi word for ÔcrunchyÕ?', 'Bingo', 'Kurkure', 'Munchos', 'Cheetos', 2),
(43, '\nAir Sahara bough by Jet Airlines was rebranded as ?', 'JetKonnect', 'Jetlite', 'Jet Blue', 'Blue Jet', 2),
(44, 'Trust Pink Forget Stains     is the tagline of which product?', 'Surf Excel', 'Vanish', 'Tide', 'Revive', 2),
(45, '\nWhich was the first Indian movie of which Singapore Airlines bought rights to broadcast it in its aircraft?', 'Dabangg', '3 Idiots', 'My Name is Khan', 'Sivaji', 4),
(46, '\nWhich of the following longitudes is the standard meridian of India? ', '69¡30ÕE', '75¡30ÕE', '82¡30ÕE', '90¡30ÕE', 3),
(47, '\nWhich of the following places receives the highest rainfall in the world?', 'Silchar', 'Cherrapunji', 'Mawsynram', 'Guwahati', 3),
(48, '\nWhich of the following river has the largest river basin in India?', 'The Indus', 'The Ganga', 'The Brahmaputra', 'The Krishna', 2),
(49, '\nWhich of the following states has the highest irrigation coverage?', 'Punjab', 'Karnataka', 'Uttar Pradesh ', 'Uttarakhand', 1),
(50, '\nWhat is the reason for the red color of the red  soil ?', 'Phosphoric Acid ', 'Humus', 'Nitrogen', 'Iron', 4),
(51, '\nWhich  one of the following states has the majority and the major oil fields in India?', 'Assam', 'Gujrat', 'Jharkhand', 'Tamil Nadu', 1),
(52, '\nSelect the correct non-renewable source of energy?', 'Hydel', 'Thermal', 'Solar', 'Wind Power', 2),
(53, '\nWhich plant hormone helps in breaking the dormancy of plant?', 'Auxin', 'Gibberellin', 'Cytokinin', 'Ethylene', 2),
(54, '\nWho had coined the term SMOG?', 'Dr. Henry Antoine', 'Stephen Hawking', 'Nicolaus Copernicus', 'Nikola Tesla', 1),
(55, '\nIn poorly ventilated buildings which one of the following inert gases can be accumulated?', 'Helium', 'Neon', 'Argon', 'Radon', 4),
(56, '\nWhat does Li-Fi Technology mean?', 'Light Fixing Technology', 'Light Fire Technology', 'Light Fidelity Technology', 'Light Firm Technology', 3),
(57, '\nMontreal protocol is related to the: ', 'Global warming', 'Ozone layer depletion', 'Sustainable development', 'Food Security', 2),
(58, '\nReducing the amount of future climate change is called:', 'Mitigation', 'Geo-engineering ', 'Adaptation', 'None of these', 1),
(59, '\nMetals are produced as waste in industries like', 'Skiing', 'Mining', 'Electroplating', 'Digging', 3),
(60, '\nWhich among these is the first artificial satellite to orbit Earth?', 'Sputnik 1', 'Explorer 1', 'Vanguard 1', 'Discoverer 1', 1),
(61, '\nThe Council of States in India is generally known as:', 'Lok Sabha', 'Rajya Sabha', 'Parliament', 'AD hoc Committee', 2),
(62, '\nUndavalli Caves ar situated in ', 'Andra Pradesh', 'Madhya Pradesh', 'Gujrat', 'Haryana', 1),
(63, '\nWho was the first Indian Scientist to win a Nobel Prize?', 'C V Raman', 'Amartya Sen', 'Hargobind Khorana', 'Subrahmanyan Chandrasekhar', 1),
(64, '\nWho is the head of the GST council?', 'Shashi Kant Das', 'Amit Mitra', 'Arun Jaitley', 'Hasmukh Adhia', 3),
(65, '\nName the hardest material present in the human body?', 'Dentin', 'Pulp', 'Enamel', 'None of the above', 3),
(66, '\nWhich of the following is the outstanding contribution of Scientist Aneriko Fermi in physics? ', 'Nuclear Furnace or Bath', 'Laws of Motion', 'Discovery of Calculus', 'Parasite', 1),
(67, '\nWhich one of the following is the first calculating device?', 'Abacus', 'Calculator', 'Turing Machine', 'Pascaline', 1),
(68, '\nIn the human body, the blood enters the aorta of the circulatory system from the', 'Left Atrium', 'Left Ventricle', 'Right Atrium', 'Right Ventricle', 2),
(69, '\nThe Federal System in India is based on the model of which country? ', 'CANADA', 'USA', 'ENGLAND', 'BRAZIL', 1),
(70, '\n 90% of the atmosphere of Jupiter is made up of which gas? ', 'Oxygen', 'Hydrogen', 'Nitrogen', 'Helium', 2),
(71, '\nIn the 2016 film Batman Vs Superman: Dawn of Justice, which character was played by Henry Cavill? ', 'Batman', 'Spiderman', 'Thor', 'Superman', 4),
(72, '\n Who is credited with inventing the water screw to help farmers ÔliftÕ water from the Nile while on a visit to Egypt? ', 'Archimedes', 'Newton', 'Pascal', 'Zivago', 1),
(73, '\nWhich is the most endangered member of the cat family in Africa? ', 'lion', 'tiger', 'Cheetah', 'Cat', 3),
(74, '\nWhich is the longest mountain range on the surface of Earth? ', 'Andes', 'k2', 'Himalya', 'Deccan', 1),
(75, '\n Which state has banned sea fishing for the duration of 7 months to protect endangered sea turtles? ', 'Bihar', 'Odisha', 'MP', 'UP', 2),
(76, '\nWhich mission of NASA brought first human to moon?', 'Space', 'Satellite', 'Discovery ', ' Apollo ', 4),
(77, '\nIn 1903 who had proposed the model of an atom, due to which electrons and protons were known to us?', ' J.J. Thompson', 'M.Nicholas', 'Newton', 'Archimedes', 1),
(78, '\nWho is the founder of FACEBOOK?', 'Larry page', 'Bill Gates', 'Mark Twain', 'Mark Zuckerburg', 4),
(79, '\nNorth Korea recently test fired a ballistic missile over which nation? ', 'Japan', 'China', 'Australia', 'Nepal', 1),
(80, '\nThe Textiles Ministry has proposed to organise Pan India camps for weavers and artisans to commemorate the birth centenary year of which former politician? ', 'Jyoti Basu', 'Pandit Deendayal Upadhyay', 'S D Sharma', 'Pranab Mukherjee', 2),
(81, '\nA group of scientists recently discovered a new species of glow-in-the-dark shark in which of the following oceans?', 'indian Ocean', 'arctic ocean', ' Pacific Ocean', 'Atlantic ocean', 3),
(82, '\n Narendra Modi became Prime minister in which year?', '2013', '2014', '2015', '2016', 2),
(83, '\nWho is the President of USA?', 'Bill Gates', 'Hillary clinton', 'Bill clinton', 'Donald Trump', 4),
(84, '\nName the muscle that act in opposition to each other? ', 'Antagonists muscle', 'Omohyoid muscle', 'Digastric muscle', 'Plantaris muscle', 1),
(85, '\nChina plans 1000-km tunnel to take which river water to Xinjiang? ', 'Brahmaputra', 'Ganga', 'Chenab', 'Kaveri', 1),
(86, '\nWhich State is called as God Own Country?Ê ', 'MP', 'UP', 'Kerala', 'Tamil nadu', 3),
(87, '\nWho was the first Governor General of India? ', 'Warren Hastings ', 'Lord mountbatten', 'General Deming', 'Lord Dalhousie', 1),
(88, '\nEstablished in 1978, which Armed Force of India uses the motto ÔVayam RakshaamahÕ meaning Ôwe shall protectÕ? ', 'Navy', 'Indian Coast Guard', 'Army', 'Airforce', 2),
(89, '\nWhich country was the backdrop of the first Tintin adventure? ', 'China', 'England', 'USA', 'Soviet Union/ Russia ', 4),
(90, '\nThe Cullinan Diamond was discovered in which continent? ', 'Africa', 'Asia', 'Europe', 'N America', 1),
(91, '\nIn which ocean did the Titanic sink on 15th April 1921 after hitting a massive iceberg? ', 'Arctic ocean', ' Pacific Ocean', 'Atlantic ocean', 'Indian ocean', 3),
(92, '\nWhich element in the halogen group is named after its color? ', 'Iodine', 'Chlorine', 'Fluorine', 'Bromine', 1),
(93, '\nWhat is the ancient name of the city of Patna? ', 'Sanchi', 'Indraprastha', 'Kautilya', 'Pataliputra', 4),
(94, '\nDelhi hosted __________ games in 2010? ', 'Asian', 'Commonwealth', 'South asian', 'saarc', 2),
(95, '\nResponsible for managing a network of more than 70,000km in India, it was formed in 1988. What is it? ', 'NHAI', 'NAHI', 'NHIA', 'NHII', 1),
(96, 'The world`s largest solar power plant was unveiled in which state of India? ', 'Tamil Nadu', 'Kerela', 'Gujarat', 'MP', 1),
(97, 'What is the main content of Bio gas?\r\n', 'Ethane', 'Methane', 'Propane', 'Butane', 2),
(98, '\nWho is termed as Father of Computers?', 'Charles Dicken', 'Charles Babbage', 'Pascal', 'Robert King', 2),
(99, '\nWhich is the least denomination Note printed in INDIA?', '10', '100', '5', '1', 4),
(100, 'Which group has launched AJIO.com?\r\n', 'TATA', 'Birla', 'Reliance', 'RPG', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `reg_id` int(6) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `attempt_flag` tinyint(1) NOT NULL DEFAULT '0',
  `started_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `score` int(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`reg_id`, `email_id`, `password`, `attempt_flag`, `started_at`, `score`) VALUES
(1, 'captainsamyak@gmail.com', '432c162bfb55f2cea618b43c27b11491', 0, '2017-11-11 10:08:31', 0),
(2, 'suas.quizwiz@gmail.com', 'b97c639c658a790589b36eace553ac7a', 0, '2017-11-11 10:14:13', 0),
(3, 'raghav.mun', '5286c47e71d841ec5b03fbd3fb42425b', 1, '2017-11-11 12:16:41', 0),
(4, 'test@test.com', 'e6b525133bc41677f40f1993f3b1f0de', 0, '2017-11-11 11:32:02', 0),
(5, 'abc@abc.com', 'dfd8b1b737994dfeed4ed7b87c3af2c0', 0, '2017-11-11 11:33:25', 0),
(6, 'raghav.mundhr', '1b9f77be482805b6966a8d42465d916d', 1, '2017-11-11 13:12:46', 2),
(7, '$email', '$password', 0, '2017-11-11 13:10:00', 0),
(9, 'deepak.mandloi@suas.ac.in', '302958797bdb0cae5fbfbb6da0ee4b43', 0, '2017-11-11 13:12:14', 0),
(11, 'v@gmail.com', '9c6d70137751997c4289b19908311589', 0, '2017-11-11 13:27:07', 0),
(12, 'vanshikasmailbox1999@gmail.com', '242ea8ed3fa6d7e174a8839665115790', 0, '2017-11-11 14:13:47', 0),
(14, 'divyagurbani1@gmail.com', 'e2e69fe1eff7b8d1012048e17a8cc0a0', 0, '2017-11-11 14:20:27', 0),
(15, 'goyalcharvi.23@gmail.com', '69d0d1430bc28b24fbb55b7565b4069c', 0, '2017-11-11 14:57:50', 0),
(18, 'simranushka@gmail.com', '55ed346161713be4df70741075765d99', 0, '2017-11-11 15:59:10', 0),
(19, 'jayeshsoni635@gmail.com', 'd0a058d821bb0b55314a7d73e1d1ca42', 0, '2017-11-11 16:04:32', 0),
(20, 'sammodtab@gmail.com', '2d29b8303fe7987a7735a4d8fd5a0b6f', 1, '2017-11-17 12:17:53', 16),
(21, 'Palkeshagrawal9@gmail.com', 'f9f617c7710e53215e73b3ee83bd65ca', 1, '2017-11-22 08:08:50', 5),
(22, 'modi.sakshi1996@gmail.com', '992156fdfe6de1aae31db6c4d7d20335', 1, '2017-11-17 09:31:19', 18),
(23, 'sg737076@gmail.com', 'edf67232482bc6d1bedb7c72a8e73831', 0, '2017-11-11 16:40:31', 0),
(24, 'divyanshu21897@gmail.com', '4d004c38ba59e8a3d2dd348925bb5c07', 1, '2017-11-17 09:06:18', 14),
(25, 'rvibhor801@gmail.com', 'a8af0d06e6edbf343b296c090116fad3', 0, '2017-11-11 17:34:15', 0),
(26, 'amanmourya48@gmail.com', '5974d08b89484bb6d749deb717fe230b', 0, '2017-11-12 04:35:48', 0),
(27, 'anantvirya@gmail.com', 'da4595c2ec70a57aa67e3e957bb56f12', 0, '2017-11-12 04:41:04', 0),
(28, 'deepakbari027@gmail.com', '6312d3df1dd2654c00ccf475360d491f', 0, '2017-11-12 04:51:01', 0),
(29, 'nav@abhayraj.net', '45eae7d13c27974641330d889d76c2b0', 0, '2017-11-12 05:23:07', 0),
(30, 'aa@gjk.com', 'd8fb6bb0e055b212fcda41f1f9ee4d45', 0, '2017-11-12 05:54:35', 0),
(31, 'sharmamuskan1607@gmail.com', 'd4fbefa4a39b8d178a00019aed7e4fca', 0, '2017-11-12 07:01:31', 0),
(32, 'meenal1118@gmail.com', '569f94024ae00212468e4cb34743a8ef', 1, '2017-11-17 12:52:32', 19),
(33, 'yfjjhjhfyyjuf@gmail.com', '3ca1a19674c5514233395a9d7a9b6b72', 0, '2017-11-12 09:34:14', 0),
(34, 'ggttsdf23@gmail.com', '164e78a81d4363aed263cf0fc004e2f6', 0, '2017-11-12 09:35:43', 0),
(35, 'abhaymourya00028@gmail.com', 'd55a04db4fe7772784cbdda9c68ed878', 1, '2017-11-17 01:31:10', 0),
(36, 'hgdfhgdfshfhfhf@gmail.com', '5d9b3af68e8a380db310aadb7c0e63ba', 0, '2017-11-12 13:19:09', 0),
(37, 'hghf@yahah.com', 'f790bec83c96f14dc5a3a1a74cc6f8d2', 0, '2017-11-12 13:21:14', 0),
(38, 'hgdfhgdfshfhfhf@ail.com', 'dd07142319720c39437a44dbcecbb0c3', 0, '2017-11-12 13:22:38', 0),
(39, 'hgdfhgdfshfhfhf@SSmail.com', '19f82779d1fc7e51c1dde6717d0f03e3', 0, '2017-11-12 13:24:21', 0),
(40, 'singh.shivatmika@gmail.com', '78d17ec00d8e30bf3b8011c80252986d', 0, '2017-11-12 13:37:42', 0),
(41, 'harshuu20@gmail.com', '7bf8dae668058d3d7a97e6106c58681b', 0, '2017-11-12 13:58:56', 0),
(42, 'taoriradhika@gmail.com', '217c205a8fce3db4e15fb018ecf89f7b', 0, '2017-11-12 18:06:07', 0),
(43, 'kamlesh_Bhopal@yahoo.com', '6e6bdf110f0b6f3645da76f840fc7dfd', 0, '2017-11-12 18:13:40', 0),
(44, 'n_merh@rediffmail.com', 'ef412546d202a8608e39aceb31d2ce70', 0, '2017-11-13 03:41:41', 0),
(45, 'bansalc10@g', 'ef412546d202a8608e39aceb31d2ce70', 0, '2017-12-01 10:18:29', 0),
(46, 'Gourgulshan88@gmail.com', 'bf42872f65a04cc69d31392f2e8ee945', 1, '2017-11-17 07:33:24', 14),
(47, 'mundhraraghav8@gmail.com', '67d2ea4856de7b0a91af563fda898305', 0, '2017-11-13 04:49:19', 0),
(48, 'raghav.mundhra3011@gmail.com', '3460fd4de10ffa237478938a3d735648', 0, '2017-11-13 05:03:24', 0),
(49, 'sachinmurkutecc.2015@gmail.com', '33540d2fddfdf1cf26a7913eaed7c970', 0, '2017-11-13 05:31:12', 0),
(50, 'ritesh.rathore501@gmail.com', 'ec4d146e61248c224ad90b9e1ac6a281', 0, '2017-11-13 05:39:36', 0),
(51, 'aayush.ukey@gmail.com', 'c64f7f2ffd5167ddae357509a52792e9', 0, '2017-11-13 05:42:29', 0),
(52, 'aviukey12345@gmail.com', '2a5647da5ca13ec17d669b44b1f89f05', 0, '2017-11-13 05:45:47', 0),
(53, 'shubhanshu31c@gmail.com', '0007b972467053ca125d12a78f0d836e', 0, '2017-11-13 05:51:46', 0),
(54, 'shaily9041@gmail.com', '2e1abbabf3b8a0a367239102ccca7ea1', 0, '2017-11-13 06:12:59', 0),
(55, 'manavrawat727@gmail.com', '779e4fa562d955a94d303fee6efddf15', 0, '2017-11-13 06:46:30', 0),
(56, 'dakshkushwah2001@gmail.com', '27a2b28161a5b8a322fdfd5cb0ee6597', 1, '2017-11-22 08:30:08', 19),
(57, 'abhiias2003@gmail.com', 'e7592e0f16f2d9147f6715fcef9077b9', 1, '2017-11-22 15:57:48', 18),
(58, 'jackyyadav14@gmail.com', '60affd6d158d68cf8e39d5c44c8dc937', 0, '2017-11-13 07:49:14', 0),
(59, 'mittal.aayushi01@gmail.com', '93971ae0ad3cbec51a94491ede8f0845', 0, '2017-11-13 07:49:43', 0),
(60, 'priyanshigarg116@gmail.com', '73d19ded91d0a035dff5555b2ee8c28f', 1, '2017-11-17 05:26:10', 13),
(61, 'talvinder214@gmail.com', '22dd1dd0828461370842de344bd0aa53', 0, '2017-11-13 08:37:52', 0),
(62, 'pragati.dhundale@gmail.com', 'e18f7e14f75d91e612c912b96261f4d1', 1, '2017-11-17 13:26:34', 0),
(63, 'sakalley.aabhas@gmail.com', 'f4343d338e7b4a12677257cc7c013fbf', 1, '2017-11-17 06:45:14', 13),
(64, 'gautamsuthargps@gmail.com', 'f30baa6f861be4c477c0e2f3b0c6e547', 0, '2017-11-13 08:52:32', 0),
(65, 'gautamsutharcc2015@gmail.com', '17037ecabd855b0f28db93b5af674d23', 0, '2017-11-13 09:05:13', 0),
(66, 'msparasmal@gmail.com', '94934e5f2759f2491dca8e4890acff65', 0, '2017-11-13 09:06:55', 0),
(67, 'hahahaha@hhahah.com', 'dba2ea2ae2504841dcd76a98a30a77fe', 0, '2017-11-13 09:21:39', 0),
(68, 'ruchikaasawa@gmail.com', '25a50241f6351d55414f113890c7341c', 0, '2017-11-13 09:53:36', 0),
(69, 'bothrayash6@gmail.com', '3f2b936b8f8067079f8177cfbb6800ff', 0, '2017-11-13 09:58:03', 0),
(70, 'nainasharda1@gmail.com', '2e58eb2abd9496a97a1e96e234fbafda', 0, '2017-11-13 10:00:08', 0),
(71, 'majoradi5@gmail.com', '1fcdeb63d84920f8947d0bb36cad7b1f', 1, '2017-11-17 10:57:49', 9),
(72, 'justinvarghese59519@gmail.com', '510f3e138b223584068fc3c543b292ad', 1, '2017-11-17 09:13:29', 10),
(73, 'preetimishra1301@gmail.com', '810931e29ec1f6b808c82bcf6538d47a', 1, '2017-11-17 07:20:02', 16),
(74, 'niharika1204ind@gmail.com', 'e8f3fc6348042788e0436d113168b03f', 0, '2017-11-13 11:37:17', 0),
(75, 'apathak431@gmail.com', '618513325440c7a1b263cf32c69ba97d', 0, '2017-11-13 11:38:57', 0),
(76, 'kavyadwivedi1999@gmail.com', '707dd6e7e0eb5958c07e141b96806631', 0, '2017-11-13 11:40:21', 0),
(77, 'anitaayachit2510@gmail.com', '327073ef7734a6166bdd43b146183f9e', 0, '2017-11-13 11:43:52', 0),
(78, 'VANSHAJsingh2711@GMAIL.COM', 'fddf010bc272138a7c73267b18d26bda', 0, '2017-11-13 11:44:16', 0),
(79, 'dhruvkagarwal@gmail.com', 'e80de7de5d8c2d1a9baa71948022dccb', 0, '2017-11-13 11:44:22', 0),
(80, 'madhavprasad1601@gmail.com', '3eea614903a3e7071efd2ff04d077171', 0, '2017-11-13 11:50:58', 0),
(81, 'swapnilverma1029@gmail.com', '86d45a1cfbd6da0b43ccd9bd0ae2a9f7', 0, '2017-11-13 12:22:00', 0),
(82, 'lawyeryatharth1@gmail.com', 'f553d1461a010dbbc31ee2a96e38059c', 1, '2017-11-17 12:23:21', 11),
(83, 'prakhar.saxena98@gmail.com', 'c2ee2049100a931a824984411ec2e1a7', 0, '2017-11-13 13:03:49', 0),
(84, 'ashishpatidar12@gmail.com', '753d558921456593208df0f86baa9a09', 1, '2017-11-21 12:09:57', 0),
(85, 'pulkitmaheshwari01@gmail.com', 'e3e8fd960c57298ae364c14634158524', 1, '2017-11-22 08:52:45', 20),
(86, 'shreyachouhan13@gmail.com', '0c72e314e818cd92c9dee8cbc4a91979', 0, '2017-11-13 13:19:06', 0),
(87, 'ayushkanha12@gmail.com', 'ca1232e6d6d9d1593f2b957490f9e851', 0, '2017-11-13 13:37:01', 0),
(88, 'dishadjmodi@gmail.com', '9bf6af564c0dceafcc40a817cc95b315', 0, '2017-11-13 14:33:43', 0),
(89, 'madhvimanghnani@gmail.com', 'f124f656638f4aeb25e23efe2ad6f2a6', 0, '2017-11-13 14:48:41', 0),
(90, 'kavyamaheshwari128@gamil.com', 'ac3f1f46d6b686db6e730d4abfca3922', 0, '2017-11-13 14:56:58', 0),
(91, 'satya.patidar@gmail.com', '67d2ea4856de7b0a91af563fda898305', 0, '2017-11-13 15:05:59', 0),
(92, 'ronaksingh777088@gmail.com', 'b052fb1402ffe116927ddb047664411d', 0, '2017-11-13 15:19:16', 0),
(93, 'Adibkhanp@gmail.com', '0c20bb942cec28cf41b553775da4bf3c', 1, '2017-11-17 06:59:04', 14),
(94, 'aabansal1@gmail.com', '9b8f671c912ca240b4cd2fe70ff52929', 0, '2017-11-13 15:37:08', 0),
(95, 'pandeyritika906@gmail.com', '27aa2acc21af0500384d9a5ac61beb15', 1, '2017-11-17 16:47:28', 0),
(96, '2001rohitrajput@gmail.com', 'b62a1cbeec90d37f19aa3387c7bc2302', 0, '2017-11-13 16:03:10', 0),
(97, 'vanshikathakur410@gmail.com', 'a0120260b15ce491d8327173a982712f', 0, '2017-11-13 16:10:22', 0),
(98, 'swapnilchourasiya19@gmail.com', '8e854ec2a6b11bc67da64726cf8ae37d', 0, '2017-11-13 17:49:40', 0),
(99, 'Shivam.agrawal13@yahoo.com', '4f1cd66ba4c8132526eab5b621e98135', 0, '2017-11-13 17:54:14', 0),
(100, 'buntyc885@gmail.com', 'd1e93bee57f550f5114d4822c153d788', 0, '2017-11-13 20:12:48', 0),
(101, 'kourharneet1903@gmail.com', '70c8511eb95b1ddbcbde6e6e859362f8', 0, '2017-11-14 03:44:27', 0),
(102, 'ekanshkochar97@gmail.com', 'e8f3fc6348042788e0436d113168b03f', 1, '2017-11-22 11:39:20', 19),
(103, 'itabhishekpatidar@gmail.com', '788d4daeb2c2351fb16cc14e7986e6ca', 0, '2017-11-14 06:19:29', 0),
(104, 'sarang@srvmedia.com', '79424043fd63e691a8f0b4b4bf7e83c9', 0, '2017-11-14 06:50:09', 0),
(105, 'akshita.neema@gmail.com', 'e3ce8ccc65bb5ba323c30f03c1f89985', 1, '2017-11-17 07:24:14', 16),
(106, 'priyajain1267@gmail.com', '8060e06e7590637bc9966f4e5c1ceedf', 0, '2017-11-14 07:06:41', 0),
(107, 'parththakkar66392@gmail.com', '5278c116c06c39a97bbe40cb3601b1e2', 0, '2017-11-14 07:08:04', 0),
(108, 'Ytripathi959@gmail.com', '4acae59ddcb0946991807f8bb1e67822', 0, '2017-11-14 07:23:01', 0),
(109, 'bhumikaghindani46@gmail.com', 'ba54cc58dfe21cfc5b529ff8d97851cf', 1, '2017-11-17 07:24:39', 19),
(110, 'jainsamyak330@gmail.com', 'b841028a3e2a4cc082d760ce3b836fd6', 0, '2017-11-14 08:47:25', 0),
(111, 'hitesh.parkhe05@gmail.com', 'a267546fee8cd388d38769e087ecfad5', 1, '2017-11-17 09:36:22', 16),
(112, 'qwert12@gmail.com', 'dd37f4277dde081b77eb77f84362756c', 0, '2017-11-14 08:59:09', 0),
(113, 'qwert123@gmail.com', '6405a8fbbde2a0e4c28a87be76c4edd5', 0, '2017-11-14 09:00:36', 0),
(114, 'kushwahchetan551@gmail.com', '5ac499c9c09a055567f59ae69ed5819e', 0, '2017-11-14 09:28:09', 0),
(115, 'malviyaaniket36@gmail.com', '34ebe1691d0f1877161d06823d0a16ef', 1, '2017-11-17 10:13:12', 16),
(116, 'rai_kamini123@rediffmail.com', 'ca128cf59616140f8108a510f0f8d4cf', 0, '2017-11-14 10:35:02', 0),
(117, 'christid.0903@gmail.com', 'c8fab2b604d88c57874589a6acb82d1a', 1, '2017-11-17 11:37:56', 0),
(118, 'agrawal.atharv@gmail.com', 'f1b71c7ced701a217d5c14732abcd168', 0, '2017-11-14 12:07:57', 0),
(119, 'laksh@df', 'd4e205d5e664931452fbc5138503ba96', 0, '2017-11-14 12:10:01', 0),
(120, 'fuqena@banit.me', 'c5a3ecdb912de5b870aefb03403cbf37', 0, '2017-11-14 12:31:59', 0),
(121, 'xewulyv@nada.ltd', 'ee9923499b67f2e5350a1fc43f305e68', 0, '2017-11-14 12:36:02', 0),
(122, 'pekucyta@amail.club', 'eac0d5c9fd4b5da02b52429a72cf8629', 0, '2017-11-14 12:39:09', 0),
(123, 'sskant@iitk.ac.in', '63e66d9c0dbb4d7ec6f72022afd5b3a9', 0, '2017-11-14 12:42:42', 0),
(124, 'vnaman555@gmail.com', '0b0085f1f210ec704608ac340c0caa37', 0, '2017-11-14 14:28:00', 0),
(125, 'nancy.sharma99@yahoo.com', '9da2dd3200448d5511e667f1c65a5ce4', 1, '2017-11-17 04:56:06', 16),
(126, 'harshdeepsahu7@gmail.com', 'ee32f947f73c5bf4bb87404d08d1d78d', 1, '2017-11-17 11:58:28', 11),
(127, 'aroraashish471@gmail.com', 'e8d22cba745a9b0185c7351486408b5d', 0, '2017-11-14 15:26:45', 0),
(128, 'sourabhswamy19@gmail.com', '4bfa37713790ca4cac7eaabf24757482', 1, '2017-11-17 12:57:25', 15),
(129, 'mayankmanager100@gmail.com', '357356e26a85ae10aa5b90069647b5dc', 1, '2017-11-17 11:20:13', 0),
(130, 'sanuj8972@gmail.com', 'bf42872f65a04cc69d31392f2e8ee945', 0, '2017-11-14 17:28:57', 0),
(131, 'patelkartik608@gmail.com', '439425a22ed55661f05656ed51bc0581', 0, '2017-11-15 03:45:39', 0),
(132, 'iammansigupta25@gmail.com', '93e60c243f15fe14950a38aa56c76e01', 1, '2017-11-17 06:05:04', 5),
(133, 'amber8719.patodi@gmail.com', '476f6967cce5ed648a928665c1cd4298', 1, '2017-11-23 06:03:54', 11),
(134, 'ribhavsingh99@gmail.com', 'b3ba57c50f2c9ebbd83d062173c3f50e', 1, '2017-11-21 14:15:22', 11),
(135, 'garvitjain8855@gmail.com', 'd4ff18fd7cbda35933cb2694e0db77d8', 0, '2017-11-15 04:33:33', 0),
(136, 'asdfghjk@gmail.com', '7cb59709b68d1691ad798d02b114bdc6', 0, '2017-11-15 04:50:03', 0),
(137, 'amitpatil@gmail.com', '0ce1f3bdf8583c2d3acf4081b9896eed', 0, '2017-11-15 05:01:58', 0),
(138, 'neiljaitly7963@gmail.com', '5bb650d7c4bed3d01e3f6b63fb8cae97', 0, '2017-11-15 05:08:29', 0),
(139, 'tanukhetpal@gmail.com', 'ca48cb39277b061b34e53eab511fbeb3', 0, '2017-11-15 05:12:14', 0),
(140, 'vedantdixit@gmail.com', 'c62d9e521fa2266b33a21c4f0a2012ac', 0, '2017-11-15 05:22:59', 0),
(141, 'ha@gmail.com', '0006bebe6d17b5223edb7d124e71defe', 0, '2017-11-15 05:38:20', 0),
(142, 'akshitabhojanirp@gmail.com', '4841949ac164f46ad929b84365c2f8c2', 1, '2017-11-23 04:58:50', 12),
(143, 'asd@gmail.com', '9c461c52f895b0b3a91d871823e087f9', 0, '2017-11-15 05:55:02', 0),
(144, 'tanpuretarun@gmail.com', '9ec125effd571f89504d6aa388992fc7', 0, '2017-11-15 06:54:18', 0),
(145, 'sonimohit895@gmail.com', 'de474924ccd17bac0bc15bf5089450d2', 0, '2017-11-15 07:47:54', 0),
(146, 'anc@gmaik.com', '25cd127c648d6adbbb0539cc0e539ac0', 0, '2017-11-15 08:21:31', 0),
(147, 'okolok@gmail.com', 'a70304b5d3b44f5c981beda4ac76f69d', 0, '2017-11-15 08:27:44', 0),
(148, 'murtaza0411@gmail.com', 'c4498b2c1f548f9027ccf6edf5c9e650', 0, '2017-11-15 08:36:04', 0),
(149, 'palakmanglani4@gmail.com', '2d48c450f12d16efbfdcb43d91ccb253', 0, '2017-11-15 08:54:17', 0),
(150, 'raghavshri123@gmail.com', '969ae0c8f0b4045d0edbf0a69b3163c4', 0, '2017-11-15 10:50:03', 0),
(151, 'purvabaderia@gmail.com', '456fec2611cdf626713f99fd323834f3', 0, '2017-11-15 13:07:04', 0),
(152, 'khanasma2010@gmail.com', 'adedeab2d20e07c8cc8e227a881ca9db', 0, '2017-11-15 13:58:28', 0),
(153, 'viditjain514@gmail.com', '018aaca520213e8ea16208f95ef28451', 0, '2017-11-15 14:06:06', 0),
(154, 'vikasmishra89625@gmail.com', '215e83ddcea0d1bdedc2da94ac9b164d', 0, '2017-11-15 14:19:19', 0),
(155, 'gautamakash33@gmail.com', '3daeb7572487322142a2010f1f8f6f1f', 0, '2017-11-15 14:27:50', 0),
(156, 'parthshukla56@gmail.com', '6eb6ce16a958a43b2a8ad988650e9252', 1, '2017-11-17 03:58:20', 12),
(157, 'vashachoudhary907@gmail.com', '7dee622b8d52e7bacbd806233957bd87', 0, '2017-11-15 14:36:06', 0),
(158, 'varshachoudhary907@gmail.com', '850032ea8b451a6b8d3e5bb2513cf386', 0, '2017-11-15 14:37:16', 0),
(159, 'dharpuresurbhi4@gmail.com', '24cb9b44e10f58cc531df22c8e5f1ee8', 0, '2017-11-15 14:37:27', 0),
(160, 'jhasbasant0101@email.com', '8690f590213857909e2ddf67e6a75432', 0, '2017-11-15 14:41:16', 0),
(161, 'sweety.harpreet02@gmail.com', 'f5f7cfc8084bc8dc2644ac477d873b20', 0, '2017-11-15 14:43:19', 0),
(162, 'rahulmewari00@gmail.com', '021979b66fda5076fe892953ab0243f7', 0, '2017-11-15 14:43:29', 0),
(163, 'shubhamparihar200@gmail.com', '6031591817e9fe11d8fefd5df59f4c8f', 0, '2017-11-15 14:48:18', 0),
(164, 'kratikatripathi97@gmail.com', 'f8eb931721424ddfecee6fa7da4fe3f4', 1, '2017-11-17 07:10:10', 13),
(165, 'aneesha.2096@gmail.com', '562f1786fbeee5d8478925dd6b088bb3', 0, '2017-11-15 14:56:58', 0),
(166, 'vid.tiwari@gmail.com', 'fb54c388b46d8dd942aea5e4b7c440f4', 0, '2017-11-15 15:00:22', 0),
(167, 'salonibhagat22@gmail.com', '1bcedcde7fc12cad200b268fa360165c', 0, '2017-11-15 15:04:08', 0),
(168, 'Ayush11malviya@gmail.com', '53f7ab7e8fb9da0d74c59e3706bb859f', 0, '2017-11-15 15:45:01', 0),
(169, 'itansha.977@gmail.com', '61f5eac647ac38c11dc7014754dddbf2', 0, '2017-11-15 16:02:01', 0),
(170, 'tomarsrajan31@gmail.com', 'c5e01c501c6cf46cf69b94c26563d6dd', 1, '2017-11-17 09:06:03', 18),
(171, 'kshitijsaonane@gmail.com', '8ebfe0aeac5dfaf8a2adc84075edf32c', 0, '2017-11-17 07:40:57', 1),
(172, 'kushalsheth2565187@gmail.com', '473a3923def74e8e31602822c2739587', 0, '2017-11-15 16:16:56', 0),
(173, 'gauravsen03014@gmail.com', 'acedf8a398be25ab93fa041383aa45ea', 0, '2017-11-15 16:25:44', 0),
(174, 'aojaswankhede24@gmail.com', '1c421f7f3fc769300accfe92bef96bd2', 0, '2017-11-15 16:26:50', 0),
(175, 'patidarnikita99@gmail.com', '95851c77faa03b6a0b0f60e92caf0096', 1, '2017-11-22 11:47:19', 11),
(176, 'raghuaayu1313@gmail.com', '755164e262ef6572d7934ff93412bc8f', 1, '2017-11-17 08:05:53', 0),
(177, 'ankurchadda232@gmail.com', '3ac7392ba649e11217789ba8f0c01023', 0, '2017-11-15 17:09:44', 0),
(178, 'biharitraders2008@gmail.com', 'a26ba2b0b580d0919d32b806241dc901', 0, '2017-11-15 17:15:16', 0),
(179, 'siddharthchouhan27@gmail.com', 'a1242d81c03fe859527c436b346658eb', 1, '2017-11-17 13:56:14', 17),
(180, 'sonianay1997@gmail.com', '336c77638a38e8088be9383631178f8b', 0, '2017-11-15 18:22:16', 0),
(181, 'kumarmayank153@gmail.com', 'ebb15b532ae454819cd38d7fd950dfe8', 0, '2017-11-15 22:41:05', 0),
(182, 'sinukoushal4677@gmail.com', '70b38bb1e9e2fb27417007b67b3ccb74', 0, '2017-11-16 02:41:49', 0),
(183, 'kalpnakoushal77@gmail.com', 'c61feb45569b7f1d3e2280f39f6e27ba', 0, '2017-11-16 02:45:08', 0),
(184, 'swatijoshi1102@gmail.com', '29b0dfa8e0307e524ebefdd5e1bc2649', 0, '2017-11-16 02:51:49', 0),
(185, 'chughmeenakshi3@gmail.com', 'fb289b49e13df835a2e11e195b8bfa0f', 1, '2017-11-17 12:50:16', 8),
(186, 'adityagupta.1319@gmail.com', 'd9ca4cf369af3317cad7fc20ceeaae19', 0, '2017-11-16 06:48:16', 0),
(187, 'uzma.khan1495@gmail.com', '7350c749ca39fc8758acce3829a65d86', 0, '2017-11-16 08:23:05', 0),
(188, 'jamirmulla@gmail.com', '5562e75bcbf00c182b2e7c981be38ede', 0, '2017-11-16 12:46:42', 0),
(189, 'upendra160284@gmail.com', '9e48681c0dbe2fcdb010625c9bdcd70f', 1, '2017-11-17 14:02:04', 17),
(190, 'jhanvi368@gmail.com', 'dd44cf4ed9363b1cfa501d52e85e0563', 1, '2017-11-18 06:15:17', 20),
(191, 'Ladshaily@gmail.com', '512794b28517c91b3c3a121dec15bb85', 1, '2017-11-17 13:21:44', 0),
(192, 'maluvinamra3@gmail.com', 'd8fb6bb0e055b212fcda41f1f9ee4d45', 1, '2017-11-22 15:23:00', 0),
(193, 'tjreddy.ece@gprec.ac.in', '5b06a03036ca0d962b681d8ca66c6dd6', 0, '2017-11-16 18:26:12', 0),
(194, 'officialwork98@gmail.com', '1c4508e7a071d646b392f30e4720a293', 1, '2017-11-21 13:11:54', 15),
(195, 'tarang@connekt.in', 'bb60bf51f22bfb392c0993b7e605fb85', 1, '2017-11-21 14:42:30', 10),
(196, 'purnimmalu25@gmail.com', '60db63fc9755699c04fa79c66d213386', 1, '2017-11-21 15:12:49', 12),
(197, 'pshewani.ps@gmail.com', '24cff0369184b1d556f716d83cd8782c', 1, '2017-11-22 05:27:59', 14),
(198, 'kirti.ranka7@gmail.com', '64cb6f9981bb6b518b35a1abcdfa9311', 1, '2017-11-21 18:19:47', 17),
(199, 'dwivediroochin@gmail.com', '5a9a156567d1b3a6374ee1eb7cd3efe1', 1, '2017-11-22 06:24:24', 6),
(200, 'rishab_pareek@yahoo.com', 'fa2968710f138b86f0fa992bebc9da9b', 1, '2017-11-22 07:04:20', 13),
(201, 'abairagi850@gmail.com', '3e65f129be8af42f2168e2b79c570585', 1, '2017-11-22 09:28:55', 6),
(202, 'swatijoshi123@yahoo.com', 'c72b345db75831c052ef057ca3b722b2', 1, '2017-11-22 11:40:47', 10),
(203, 'chayanbansal@outlook.com', '6391d79d98272c3e7245b26815eb7f17', 1, '2017-11-23 06:31:44', 4),
(204, 'ranveersinghaniya44@gmail.com', '4e4ddf0e03c3c301cdc537be58624c5a', 1, '2017-11-22 15:59:16', 1),
(205, 'sanjaypunwani4@gmail.com', '77d1892248ddfcc53f038a7e44f635d2', 1, '2017-11-22 19:35:17', 13),
(206, 'raghvendras112@gmail.com', '5cc5b0a0d45a8c1c8d0036c4e0c34d98', 1, '2017-11-23 04:54:45', 9),
(207, 'yashvijayvargiya11@gmail.com', 'e23a80171910dc6f602115a41f5f4c89', 1, '2017-11-23 05:01:19', 11),
(208, 'sumitkrishna999@gmail.com', '92a57ff36be9998c27bfbadb01c3f52d', 0, '2017-11-23 06:37:03', 0),
(209, 'prachipranji@gmail.com', '8c8b5bdbebcf2fe4e9efe48e0ac09560', 1, '2017-11-23 14:28:12', 19),
(210, 'praspatel894@gmail.com', 'a267546fee8cd388d38769e087ecfad5', 1, '2017-11-24 04:39:25', 16),
(211, 'satishspatidar@gmail.com', '26c14b3444d2a0423af25bab75097c22', 1, '2017-11-24 04:05:37', 19),
(212, 'jaiswalritik816@gmail.com', '4e7c732d33dcd2c0684409902f1a5306', 1, '2017-11-24 04:23:12', 19),
(213, 'sakshi9009088400@gmail.com', '72029471825191615355839746fd89eb', 1, '2017-11-24 08:37:29', 19),
(214, 'shruti9424051379@gmail.com', '3fabd3c0bfab79102b1d023fa0b4d54a', 1, '2017-11-24 08:51:36', 13),
(215, 'harendrarautela19@gmail.com', 'dfd2a09748d1efce7cdde58bc40053ff', 1, '2017-11-24 15:35:38', 10),
(216, 'bansalc10@gmail.com', '5f83e981d131ffd41e8f09691d2a34da', 1, '2017-12-01 10:21:17', 6);

-- --------------------------------------------------------

--
-- Table structure for table `user_detail`
--

CREATE TABLE `user_detail` (
  `reg_id` int(6) NOT NULL,
  `name` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `gender` text NOT NULL,
  `father_name` varchar(30) NOT NULL,
  `phone_no` varchar(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(20) NOT NULL,
  `pincode` int(6) NOT NULL,
  `standard` int(2) NOT NULL,
  `stream` varchar(12) NOT NULL,
  `name_of_institution` varchar(100) NOT NULL,
  `college_flag` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_detail`
--

INSERT INTO `user_detail` (`reg_id`, `name`, `dob`, `gender`, `father_name`, `phone_no`, `address`, `city`, `pincode`, `standard`, `stream`, `name_of_institution`, `college_flag`) VALUES
(1, 'Samyak', '2017-12-31', 'M', 'Jain', '8898987845', 'V-23', 'Indore', 453331, 0, 'N/A', 'SUAS', 1),
(3, 'Raghav', '2017-12-31', 'F', 'lkhukgh', '7000000000', 'jkghug', 'Indore', 456789, 0, 'N/A', 'SUAs', 1),
(4, 'wee', '0001-01-01', 'M', 'werwe', '7000000001', 'wewer', 'ewrewr', 122124, 0, 'N/A', 'eweewr', 1),
(5, 'qqrwr', '0001-01-01', 'M', 'wrwrwe', '7000000001', 'rewr', 'ewerewr', 4124142, 0, 'N/A', 'werwe', 1),
(6, 'raghav', '2017-11-01', 'M', 'raghav', '9999999999', 'rrrrr', 'rrrrr', 123456, 0, 'N/A', 'rrrrrr', 1),
(9, 'MANDLOI SIR', '2017-11-09', 'M', 'FATHER', '9644959600', 'HOME', 'INDORE', 453441, 0, 'N/A', 'SUAS', 1),
(11, 'Vaibhav', '1987-06-20', 'M', 'Vilas', '7741820120', 'pune', 'pune', 411016, 0, 'N/A', 'scdl', 1),
(12, 'Vanshika gupta', '1999-04-12', 'F', 'Suresh gupta', '8319898845', '510, shanti nagar near damoh naka ', 'jabalpur', 482002, 0, 'N/A', 'symbiosis university of applied sciences', 1),
(14, 'Divya gurbani', '1999-06-09', 'F', 'Harish gurbani', '7726000240', '6-D-28 NHB SHASHTRI NAGAR', 'Bhilwara', 311001, 0, 'N/A', 'symbiosis university of applied sciences', 1),
(15, 'Charvi goyal', '1998-05-23', 'F', 'Rajesh goyal', '8989122611', '12/3 parsi mohalla chhavani ', 'Indore', 452001, 0, 'N/A', 'Amity global business school ', 1),
(18, 'Simran Bhardwaj', '1998-06-16', 'F', 'Deepak Sharma', '9123480752', '426-R mahalaxmi nagar, bombay hospital - 0731', 'Indore', 731, 0, 'N/A', 'Symbiosis university of applied sciences', 1),
(19, 'Jayesh Soni', '1999-06-03', 'M', 'Jayant Soni', '9009872424', 'H.No 124 Jawahar Marg, Mehidpur Dist. Ujjain', 'Mehidpur', 456443, 0, 'N/A', 'Symbiosis University Applied Of Science', 1),
(20, 'Samkit modi', '2000-10-28', 'M', 'Sudesh modi', '7999827452', '23\r\nGanesh dham colony, Near Brijeshwari main bengali square indore', 'Indore', 452016, 11, 'Science', 'Guru harkrishna public school ', 0),
(21, 'ratnesh agrawal', '2001-07-26', 'M', 'satish agrawal', '7748884884', '10/3 new palasia ', 'indore', 452001, 11, 'Commerce', 'emerald heights international school', 0),
(22, 'Sakshi Modi', '1996-07-19', 'F', 'Sudesh modi ', '9109652197', '23\r\nGanesh dham colony, Near Brijeshwari main bengali square indore', 'Indore', 452016, 0, 'N/A', 'Symbiosis university of applied sciences ', 1),
(23, 'Satyam gupta', '2000-06-22', 'M', 'Ramshroop gupta', '9131196110', 'Jail road tikamgarh', 'Tikamgarh', 482012, 0, 'N/A', 'Ips academy indore', 1),
(24, 'Dvyanshu Aggarwal', '1997-08-21', 'M', 'RK Aggarwal', '7840077259', 'HNO. 1542 Sector 10A  ', 'Gurgaon', 453112, 0, 'N/A', 'Smbiosis University Of Applied Sciences', 1),
(25, 'Vibhor', '1999-05-02', 'M', 'Navneet Rathi', '7389089799', 'Mukati boys hostel,murai mohalla,chawni', 'Indore', 452001, 0, 'N/A', 'Renaissance college', 1),
(27, 'Anantvirya jain', '1999-12-24', 'M', 'Sanjay jain', '9993675910', '104 royal palace peplihana indore', 'Indore ', 452001, 0, 'N/A', 'Symbiosis ', 1),
(28, 'Deepak', '1995-01-07', 'M', 'Naresh Kumar', '7728989533', 'Kant Kalwar, NH-11C, Jaipur Delhi Highway', 'Jaipur', 303002, 0, 'N/A', 'Amity University Rajasthan', 1),
(29, 'Navraaj randhawa', '1998-07-16', 'M', 'Ajit Randhawa ', '8770442024', 'E801 bcm paradise nipania Indore ', 'Indore ', 452010, 0, 'N/A', 'Symbiosis uni of applied sciences', 1),
(30, '124', '2017-11-23', 'M', '12', '9995656568', 'Mumbai', 'Mumbai', 452010, 11, 'Commerce', 'St arnold', 0),
(31, 'Muskan Sharma', '1999-07-16', 'F', 'Bhawani Shankar Sharma', '9131843644', '412 Manvata nagar, near kanadia bypass Indore ', 'Indore', 452001, 0, 'N/A', 'Symbiosis university of applied sciences Indore', 1),
(32, 'Meenal Shrivastava', '1997-11-24', 'F', 'Manoj Shrivastava', '8435793538', '205, himgiri complex wright town jabalpur ', 'Jabalpur', 452001, 0, 'N/A', 'Symbiosis University of applied science', 1),
(33, 'jkugjg', '2017-11-02', 'M', 'vhmjvmj', '7000000004', 'vjhvhjvjvjv', 'gyhujgyhjgj', 234567, 0, 'N/A', 'bgkjbkbmk', 1),
(34, 'gjygyjuyg', '2017-11-22', 'M', 'hvhjfvvfjhj', '7678678676', 'gjygtgjyugjgjgjg', 'indore', 456789, 0, 'N/A', 'sbcdhjjdscbjh', 1),
(35, 'Abhay Mourya', '2002-02-06', 'M', 'Mahendra Mourya', '8962642006', '206-M Veena Nagar Sukhliya Indore', 'Indore', 452010, 11, 'Commerce', 'St.Vincent Pallotti school', 0),
(40, 'Shivatmika Singh', '1997-06-04', 'F', 'Mr. Birendra Pratap Singh', '9755474880', 'Sai Dwarkira Girls Hostel,\r\n577 scheme 97, part 4, slice 3\r\nAnnapurna Main Road near Rajendra Nagar Railway bridge.', 'Indore', 452001, 0, 'N/A', 'Chameli Devi School of Engineering', 1),
(41, 'Harshita umdekar', '1998-02-10', 'F', 'Sanjay umdekar', '7089113428', '109,laxmi paradise, dhanvantari nagar, Annapurna road ,flat no. 201', 'Indore', 452012, 0, 'N/A', 'Chameli devi group of institution', 1),
(42, 'Radhika Taori', '1999-05-18', 'F', 'Ashish Taori', '8989834406', '302, Siddhartha Vihar 12/13 Prakash Nagar Navlakha ', 'Indore', 452001, 0, 'N/A', 'Symbiosis Universit of Applied Sciencesy', 1),
(43, 'Kamlesh', '2002-12-12', 'O', 'Kamlesh', '9999567511', 'Bhopal', 'Bhopal', 452112, 11, 'Commerce', 'Kamlesh', 0),
(44, 'Nishita ', '2002-05-16', 'M', 'Nitin', '9893444768', 'D-35 RRCAT Colony', 'Indore', 452013, 0, 'N/A', 'AEC School', 1),
(45, 'Chayan Bansal', '1998-09-02', 'M', 'Ashok Bansal', '7999656589', 'Address', 'Indore', 452001, 0, 'N/A', 'SUAS', 1),
(46, 'Gulshan gour', '1998-02-26', 'M', 'Balram gour', '9009600052', '53 gangabagh colony ', 'Indore', 452015, 0, 'N/A', 'Cdgi', 1),
(47, 'Raghav Mundhra', '1998-11-30', 'M', 'Vijay', '9981625830', 'Bsnanajsb', 'Snsjskdb', 452001, 0, 'N/A', 'Suas', 1),
(48, 'Raghav Mundhra', '1998-11-30', 'M', 'Vijay', '9981625830', 'Bsjfhdks', 'Snsjskdb', 452001, 0, 'N/A', 'Suas', 1),
(49, 'SACHIN MURKUTE', '2001-05-01', 'M', 'VIJAY MURKUTE', '7089824463', '76, MANAVATA NAGAR,  KANADIYA ROAD', 'INDORE', 452016, 12, 'Science', 'COLUMBIA CONVENT', 0),
(50, 'RITESH SINGH RATHORE', '2001-11-06', 'M', 'BALBEER SINGH RATHORE', '9630337266', '409,C-BLOCK,SANGHVI RESIDENCY,BY PASS', 'INDORE', 452016, 12, 'Science', 'COLUMBIA CONVENT', 0),
(51, 'AAYUSH UKEY', '1999-06-28', 'M', 'P R UKEY', '7772003683', '31 Chameli Villas behind agrawal public school bicholi mardana road', 'INDORE', 452016, 12, 'Science', 'COLUMBIA CONVENT', 0),
(52, 'DHANESH SHARMA', '1999-12-30', 'M', 'RAHUL SHARMA', '9584888867', '72,Bijli nagar bicholi hapsi road', 'INDORE', 452016, 12, 'Science', 'COLUMBIA CONVENT', 0),
(53, 'SHUBHANSHU CHOURASIYA', '2000-04-29', 'M', 'BASANT CHOURASIYA', '9630337266', 'Columbia Convent school bicholi hapsi road\r\n', 'INDORE', 452016, 12, 'Science', 'COLUMBIA CONVENT', 0),
(54, 'Shaily Chhabra', '1997-07-30', 'F', 'Rajkumar Chhabra', '7773847030', 'Vijay Dresses ,Sheetla Mata Road Shamgarh (M.P)', 'Shamgarh', 458883, 0, 'N/A', 'Symbiosis University of applied sciences', 1),
(55, '', '2002-08-13', 'M', '', '8878505508', 'Sikandra kampoo imili naka Gwalior', 'Gwalior', 474001, 11, 'Science', 'Doon public school', 0),
(56, 'Daksh Kushwah', '2001-05-19', 'M', 'Mr. Rajendra Kushwah', '7692824300', '1096, Bank Colony Road, Sudama Nagar', 'Indore', 452009, 11, 'Science', 'Shree Kaser Bazar Vidya Niketan', 0),
(57, 'Abhishek bhattacharjee', '2003-03-05', 'M', 'Kanchan bhattacharjee', '8827877332', 'Chouhan green valley junwani bhilai', 'Bhilai', 490023, 11, 'Science', 'MGM SENIOR SECONDARY SCHOOL BHILAI', 0),
(58, 'jaikesh yadav', '1997-12-14', 'M', 'bhupinder yadav', '9109786566', 'B-102 dew drops apartments sector-47 ', 'gurgaon', 122001, 0, 'N/A', 'symbiosis university of applied sciences  ', 1),
(59, 'aayushi mittal', '1998-04-01', 'F', 'shyam mittal', '9993631505', '201, urvashi complex, jaora compound, MY, indore', 'indore', 452001, 0, 'N/A', 'symbiosis university of applied sciences', 1),
(60, 'Priyanshi Garg', '2000-06-11', 'F', 'Vivek Garg', '8209446853', '7 mukati Nagar ,New line telephone Nagar Indore', 'Indore', 452016, 12, 'Commerce', 'Vidya Bhavan Public School', 0),
(62, 'Pragati Dhundale', '2000-09-01', 'F', 'Vijay Dhundale', '9926088873', '19/90 Nehru Nagar Road no. 9 opp. Amrit dham gate, Indore , M.P.', 'Indore', 452011, 12, 'Commerce', 'Vidya Bhavan Public School ', 0),
(63, 'aabhas sakalley', '1998-07-02', 'M', 'sajjan sakalley', '7354404748', '86,vrindavan garden pipliyahna indore', 'indore', 452015, 0, 'N/A', 'cdgi', 1),
(67, 'hahhaa', '3392-11-23', 'M', 'hahaha', '7123456789', 'hahahah', 'hahahha', 969696, 0, 'N/A', 'hahhah', 1),
(68, 'RUCHIKA ASAWA', '1996-04-23', 'F', 'ARUN KUMAR ASAWA', '9425312755', '50,SHRADDHANAND MARG,CHHAWNI', 'INDORE(M.P.)', 452001, 0, 'N/A', 'SYMBIOSIS UNIVERSITY OF APPLIED SCIENCES', 1),
(69, 'YASH BOTHRA', '1996-09-19', 'M', 'GIRISH BOTHRA', '9479688884', '4/3 MALHARGANJ,204 RAJRATAN TOWER', 'INDORE(M.P.)', 452001, 0, 'N/A', 'SYMBIOSIS UNIVERSITY OF APPLIED SCIENCES', 1),
(70, 'NAINA SHARDA', '1997-01-17', 'O', 'DINESH SHARDA', '8103057714', '120,KANYAKUBJ NAGAR,AIRPORT ROAD', 'INDORE(M.P.)', 452001, 0, 'N/A', 'SYMBIOSIS UNIVERSITY OF APPLIED SCIENCES', 1),
(71, 'Aditya Nair', '1998-10-02', 'M', 'Suresh Kumar Nair', '9131610729', '39, Revenue Nagar, Bicholi Hapsi Road\r\n', 'Indore', 475001, 0, 'N/A', 'ITM UNIVERSITY, Gwalior', 1),
(72, 'Justin Varghese', '2001-04-17', 'M', 'Kv.varghese', '9131309896', 'MIG 7  Vaibhav homes behind Queen Mary School near Ayodhya bypass road Bhopal', 'Bhopal ', 462001, 11, 'Commerce', 'Ideal School Higher Secondary Bhopal', 0),
(73, 'Utkarsh Mishra', '2001-07-30', 'M', 'Mr.Alok Mishra', '9425631647', 'Flat no.605, C1 block,Balaji Skyz, Nipaniya', 'Indore', 452010, 11, 'Science', 'Vidya Bhavan Public School', 0),
(74, 'Niharika', '1999-04-12', 'F', 'Shailesh Kumar Roy', '9340337424', 'House No. 73, Mangalmurty krishna ji nagar Scheme No. 77,Behind Mayur Hospital', 'Indore', 452001, 0, 'N/A', 'Symbiosis Universit of Applied Sciencesy', 1),
(75, 'ADITYA PATHAK', '1999-08-30', 'M', 'VIJAY PATHAK', '9893645908', 'F-44 MIG COLONY INDORE', 'Indore', 452007, 0, 'N/A', 'Symbiosis university of applied sciences', 1),
(76, 'Kavya dwivedi', '1999-12-04', 'O', 'M.k dwivedi', '8819034098', '98,prime park,limbodi,khandawa road \r\n', 'Indore', 452001, 0, 'N/A', 'Symbiosis Universit of Applied Sciencesy', 1),
(77, 'Anita S Ayachit', '1999-10-25', 'F', 'Shirish Ayachit', '9179473130', 'M-190 Vigyan Nagar Near Navneet Garden', 'Indore', 452001, 0, 'N/A', 'Symbiosis University of Applied Sciences', 1),
(78, 'Vanshaj singh ', '1998-11-27', 'M', 'Rakesh kumar singh', '7999355103', 'DD/D3 akashwani vihar residency area', 'Indore ', 452001, 0, 'N/A', 'Symbiosis university of applied sciences ', 1),
(79, 'DHRUV AGRAWAL', '1999-05-11', 'M', 'Kailash AGRAWAL', '9691433668', '17 , sawarsati nagar ,opp vashali petroleum, Annapurna road,indore', 'Indore', 452007, 0, 'N/A', 'Symbiosis university of applied sciences', 1),
(80, 'MADHAV PRASAD YADAV', '1998-01-16', 'M', 'Ramlal yadav', '9893386790', 'Kshipra,budhi barlai', 'INDORE', 453771, 0, 'N/A', 'ACROPOLIS INSTITUTE OF TECHNOLOGY AND RESEARCH,INDORE', 1),
(81, 'Swapnil verma ', '2000-03-10', 'M', 'Kailash verma ', '9131572283', '15,revenue nagar indore ', 'Indore ', 452016, 0, 'N/A', 'Symbiosis ', 1),
(82, 'Yatharth agrawal', '1997-03-30', 'M', 'Radheshyam agrawal', '8602145099', '2751 Old indore road mhow', 'Mhow', 453441, 0, 'N/A', 'SOL ,DAVV', 1),
(83, 'prakhar saxena', '1998-10-08', 'M', 'Rajendra Saxena', '8085565552', 'v + p sundarsi, dist. shajapur (M.P)', 'INDORE', 465113, 0, 'N/A', 'Chameli Devi Group of Institution, indore(M.P)', 1),
(84, 'Ashish Patidar', '2017-11-13', 'M', 'Krishna Patidar', '8358880362', '707, Dankan Road, Harsola, Mhow', 'Indore', 453441, 0, 'N/A', 'Indore Institute of Science and Technology', 1),
(85, 'Pulkit Maheshwari', '1997-07-13', 'M', 'Alok Maheshwari', '8120019696', '49,Lalaram Nagar City Boys Hostel indore', 'Indore', 452001, 0, 'N/A', 'Chameli Devi Group Of Institutions Indore', 1),
(86, '', '2001-11-04', 'F', 'Rajendra sigh chouhan', '8839429053', '43/A,ram chandra nagar, dewas,MP', 'Dewas', 455001, 11, 'Commerce', 'Vidya bhavan public school', 0),
(87, 'Ayush Gupta', '1998-04-30', 'M', 'Rajesh Gupta', '8109274930', '101,somani nagar 60 feet , indore', 'Indore', 452002, 0, 'N/A', 'chameli devi group of institution', 1),
(88, 'Disha modi', '1997-06-01', 'F', 'Manoj modi', '9753673715', '302,Girnar tower ,new palasia ,Indore ,452001', 'Indore ', 452001, 0, 'N/A', 'Institute of chartered accountant of india', 1),
(89, 'Madhvi Manghnani', '2000-10-04', 'F', 'B L manghnani', '8839884608', 'Satna', 'Satba', 485001, 12, 'Science', 'St Michael', 0),
(90, 'Kavya Maheshwari', '2001-10-31', 'F', 'Sanjay Maheshwari', '9826027110', 'N-81 anoop nagar', 'Indore', 452008, 11, 'Commerce', 'Vidya Bhavan Public School', 0),
(91, 'Raj patidar', '2002-08-08', 'M', 'Dhanpal patidar', '9926981550', '168,Arush residency sarva sampanaa nagar near columbia school', 'Indore', 4520001, 11, 'Commerce', 'Columbia convent ', 0),
(92, 'Rounak Parmar', '2001-09-20', 'M', 'Umesh Parmar', '7770880211', 'Dharampuri main road indore', 'Indore', 453551, 11, 'Commerce', 'Prestige Public School', 0),
(93, 'adib khan pathan', '1996-11-01', 'M', 'aadil khan pathan', '9575250439', '98 c kalani bagh Dewas .\r\n', 'dewas', 455001, 0, 'N/A', 'cdgi', 1),
(94, 'Aashi Bansal', '2017-11-13', 'F', 'Ashok Bansal', '9644959600', 'Home', 'Indore', 453441, 0, 'N/A', 'College', 1),
(95, 'Ritika Pandey ', '2001-11-22', 'F', 'Rajendar kumar Pandey ', '9827229506', 'Reva bhagwati nagar near collector bungalow malakhedi road ', 'Hoshangabad ', 461001, 11, 'Science', 'Servite convent Sr. Sec. School', 0),
(96, 'rohit rajput', '2001-03-10', 'M', 'hargovind singh rajput', '8839333126', 'mig2 8 sudhar nyas colony .housing board colony', 'hoshangabad', 461001, 11, 'Commerce', 'servite convent senior secondary school', 0),
(97, 'Vanshika thakur', '2001-10-04', 'F', 'Jagdish singh thakur', '7247326906', 'Rudra enclave malakhedi road f 43 hoashangabad', 'Hoshangabad ', 461001, 11, 'Science', 'Servite convent sr. Sec school', 0),
(98, 'Swapnil chourasiya', '1998-01-19', 'M', 'surendra chourasiya', '9893035845', 'Tiwari colonet Hoshangabad MP', 'Hoshangabad', 461001, 0, 'N/A', 'NMV', 1),
(99, 'Shivam agrawal', '1998-09-23', 'M', 'Chintesh agrawal', '9826094750', '1546, kayasth mohalla, mhow', 'Indore', 453441, 0, 'N/A', 'Ips', 1),
(100, 'Durgesh chouhan', '1999-10-10', 'M', 'ganesh chauhan', '8269729116', '30/4 staff colony birlagram nagda, ujjain', 'Nagda', 456334, 0, 'N/A', 'ips academy', 1),
(101, 'Harneet Kour Bhatia', '2000-03-19', 'F', 'Harbhajan Singh Bhatia', '7610775520', 'pahad Singh pura khargone MP ', 'Khargone ', 452001, 0, 'N/A', 'Symbiosis university of Applied Sciences Indore ', 1),
(102, 'Ekansh kochar', '1997-12-29', 'M', 'Surendra kochar', '8234916343', 'Kota road, suyash hospital, house no-23', 'Raipur', 492001, 0, 'N/A', 'Pragati college', 1),
(103, 'Abhishek Patidar', '2000-05-10', 'M', 'Durgashankar Patidar', '7999528271', 'Khandwa', 'Khandwa', 450001, 0, 'N/A', 'MJP Polytechnic college khandwa ', 1),
(104, 'sarang', '1993-12-18', 'M', 'ganesh', '8551900031', 'Pune', 'pune', 411045, 0, 'N/A', 'Pune University', 1),
(105, 'Akshata Neema', '1997-07-16', 'F', 'Vrindavan Neema', '8602287335', '116,Vyanktesh nagar   main near airport road', 'Indore', 452005, 0, 'N/A', 'Chameli Devi Group of Institution', 1),
(106, 'Priyanshi Jain', '1997-02-03', 'F', 'Deepak jain', '9285515117', 'Symbiosis university of applied sciences ', 'Indore', 453115, 0, 'N/A', 'Symbiosis university of applied sciences', 1),
(107, 'Parth thakkar', '1999-12-29', 'M', 'Sanjay thakkar ', '8982997987', 'Mahaveer coloney jaora,ratlam(m.p)', 'Jaora', 457226, 0, 'N/A', 'Royal college', 1),
(108, 'Yash Tripathi ', '2001-08-27', 'M', 'Akhilesh Tripathi ', '9407006324', 'Vishwanath colony near sankar temle chhatapur MP ', 'Chhatapur MP ', 471001, 11, 'Commerce', 'Shealing  public  school  chhatapur MP ', 0),
(109, 'Bhumika ghindani', '1998-09-29', 'F', 'Ajay ghindani', '9926324939', '7 anand nagar chitawad navlakha indore', 'Indore', 452001, 0, 'N/A', 'Symbiosisis university of applied sciences', 1),
(110, 'Samyak', '2017-11-30', 'M', 'Jain', '8989898989', 'dfgfdgdfgdfg', 'dfsdfsdfsdf', 323232, 0, 'N/A', 'SUAS', 1),
(111, 'HITESH PARKHE', '1998-10-14', 'M', 'PRAKASH PARKHE', '9009061926', 'RAAM BAGH, NEAR LAAL BAALTI', 'INDORE', 452010, 0, 'N/A', 'SHRI VAISHNAV VISHWAVIDYALAYA', 1),
(112, 'GFTZQDSF', '1998-07-04', 'M', 'GFDWZGFD', '7894561425', 'qwsaedrfatg', 'indore', 452003, 0, 'N/A', 'medicaps', 1),
(113, 'qwerty', '1999-02-12', 'M', 'keypad', '7899554562', 'a52njhkjh', 'INDORE', 452003, 0, 'N/A', 'suas', 1),
(114, 'Chetan singh kushwah', '1999-04-26', 'M', 'Govind singh kushwah', '7974750681', '4/7 chauthi paltan police line indore', 'Indore', 452001, 0, 'N/A', 'Medi caps university', 1),
(115, 'Aniket malviya', '1999-09-08', 'M', 'Kailash malviya', '9131704996', '203-A abhinandan nagar', 'Indore', 452001, 0, 'N/A', 'Soft vision', 1),
(116, 'Kamini Rai', '1978-07-10', 'F', 'Mr. Radha Kishan Jaiswal', '9993644838', '270/9, Shastri Nagar Colony', 'Ujjain', 456010, 0, 'N/A', 'Vikram University', 1),
(117, 'Christina', '2001-03-09', 'F', 'Terence', '9039777360', 'G 103 Dsouza House\r\nMIG Colony', 'Indore', 452010, 12, 'Commerce', 'Prestige Public school', 0),
(118, 'Atharv Agrawal', '1998-03-31', 'M', 'Arun Agrawal', '9644886697', '2787 tangha khana near shastri garden', 'Mhow', 453441, 0, 'N/A', 'Gujrati', 1),
(122, 'xewulyv@nada.ltd', '2017-11-01', 'M', 'xewulyv@nada.ltd', '9999999999', 'xewulyv@nada.ltd', 'xewulyv@nada.ltd', 569875, 0, 'N/A', 'xewulyv@nada.ltd', 1),
(124, 'Naman', '1999-02-10', 'M', 'Pankaj', '9039113502', 'N 79 sanchar nagar extension', 'Indore', 452016, 0, 'N/A', 'Medicaps University', 1),
(125, 'Nancy Sharma', '1999-05-03', 'F', 'Arun Sharma', '8989461999', '173 Sarvasampanna Nagar', 'Indore', 452016, 0, 'N/A', 'NMIMS Mumbai ', 1),
(126, 'Harshdeep Sahu', '1997-12-07', 'M', 'Sunil Sahu', '7869705370', '24/60 New Dewas Road,Indore', 'Indore', 452001, 0, 'N/A', 'Renaissance College of Commerce and Management', 1),
(127, 'Ashish Arora', '1999-06-29', 'M', 'Ravindra Kumar Arora', '8226000064', 'B-11,Vistara Township,Indore,M.P.', 'Indore', 452016, 0, 'N/A', 'SUAS', 1),
(128, 'Sourabh Swamy', '1997-08-19', 'M', 'Ajay Swamy', '8085898995', '2751 Yadav Mohalla Indore Road Mhow', 'Mhow', 453441, 0, 'N/A', 'Medicaps Institute Of Technology and Management', 1),
(129, 'Mayank Patidar', '1998-09-20', 'M', 'Mr. Mohan Patidar', '8770515110', '742, Khajarana, Indore', 'INDORE', 42010, 0, 'N/A', 'pioneer institute of professional studies', 1),
(130, 'Anuj singh', '2000-03-16', 'M', 'Jitendra singh', '9644459205', '143 anoop nagar ', 'Indore', 452008, 0, 'N/A', 'Symbosis University of applied sciences', 1),
(131, 'Ritik patel', '2000-10-08', 'M', 'Hareram patel', '7805054672', 'Indore', 'indore', 46200, 0, 'N/A', 'school', 1),
(132, 'Mansi Gupta', '1999-12-25', 'F', 'Jagdish Gupta', '8827075538', '11/2 Race Course Road ,Indore (M.P)', 'Indore ', 452003, 12, 'Commerce', 'Vidya Bhavan Public School , Indore ', 0),
(133, 'Amber patodi', '1999-04-21', 'M', 'Manoj patodi', '8719871987', '21 hukum chand marg ', 'Indore', 452001, 0, 'N/A', 'Suas', 1),
(134, 'Ribhav singh', '1999-09-29', 'M', 'Vivek singh', '8120206523', '454 panchvato colony ', 'Indore', 452001, 0, 'N/A', 'Suas', 1),
(135, 'Garvit jain', '1999-10-07', 'M', 'sukumar jain', '8770871143', '15 shikshak nagar', 'indore', 452005, 12, 'Commerce', 'shri rk daga maheswari ', 0),
(137, 'amit', '2017-11-16', 'M', 'patil', '9876540999', 'r7u5tu vytyu tyu t yut yutyu tyu hjyug yugyu ygyf', 'indore', 345345345, 0, 'N/A', 'davv', 1),
(138, 'neil jaitly', '1998-07-03', 'M', 'anil jaitlty', '9930975925', '100 Anand nagar indore', 'indore', 452001, 0, 'N/A', 'suas', 1),
(139, 'Tanishq Khetpal', '1998-12-10', 'M', 'Sunil Khetpal', '7869372204', '51 52 Sarvodaya Nagar Indore', 'indore', 452001, 0, 'N/A', 'Symbiosis University of Applied Sciences', 1),
(140, 'VEDANT DIXIT', '1999-03-25', 'M', 'ASHOK DIXIT', '9893102200', 'E 47 SAKET NAGAR ', 'INDORE', 452001, 0, 'N/A', 'VAISHNAV COLLEGE INDORE', 1),
(141, 'xyz', '1999-02-28', 'M', 'abc', '9651112344', '123fncvxn,76', 'indore', 453112, 0, 'N/A', 'suas', 1),
(142, 'akshita bhojani', '2000-03-16', 'F', 'rakesh bhojani', '9826964040', 'kalpana apartment choti gwaltoli ', 'indore', 452001, 0, 'N/A', 'suas', 1),
(143, 'asd', '2017-11-02', 'M', 'asd', '9876543210', '1234wertsgv', 'dghfg', 345763, 0, 'N/A', 'suas', 1),
(144, 'Tarun tanpure', '1996-05-31', 'M', 'Roop rao tanpure', '8871748105', '3570E sudama nager indore', 'Indore', 452009, 0, 'N/A', 'Indore institute of managment', 1),
(145, 'Mohit soni', '1985-06-24', 'M', 'Harish soni', '9179353589', 'sury sadhna, 7 luv kush vihar colony near aata chakki ,sabji mandi road , sukhliya, indore', 'Indore', 452010, 0, 'N/A', 'Piemr', 1),
(146, 'Anushka Mandloi', '1998-05-04', 'M', '', '9234567890', 'Suas Indore', 'Indore', 452001, 0, 'N/A', 'SUAS', 1),
(147, 'kjjkn', '1917-07-25', 'O', 'kkuuk', '7000000000', ' jh8yutg67yghy88', 'indore', -1, 0, 'N/A', 'guvukvbi', 1),
(148, 'Murtaza Farshiwala', '2001-05-05', 'M', 'Mustafa Hussain Farshiwala', '9424017393', 'Swam shraddhanad marg san gali khandwa ', 'Khandwa', 450001, 11, 'Science', 'S.t Joseph convent sr.sec school', 0),
(149, 'Palak Manglani', '1998-03-04', 'F', 'Dinesh Manglani', '9669442211', 'E 76 Saket Nagar', 'Indore', 452001, 0, 'N/A', 'SUAS', 1),
(150, 'raghav shrivastava', '1998-12-19', 'M', 'Mr. Mohan Shrivastava', '8719898306', 'CJRM 30, Sukhilya Indore,\r\nMP', 'Indore', 452010, 0, 'N/A', 'Symbiosis University of Applied Sciences', 1),
(151, 'Purva', '1997-06-30', 'F', 'Mahesh Baderia', '8964000739', 'Indore', 'Indore', 452001, 0, 'N/A', 'Icai', 1),
(152, 'ASMA KHAN', '1989-09-20', 'F', 'MOHAMMED AYYUB KHAN', '8889492891', '332-c MAIN STREET DREAMLAND SQUARE MHOW', 'MHOW', 453331, 0, 'N/A', 'IIMR', 1),
(153, 'ViDit Jain', '1995-02-13', 'M', 'Vimal jain', '9479774514', 'Near hello point, indrapuri colony bhawarkua indore', 'Indore', 452001, 0, 'N/A', 'Indore institute of management & research', 1),
(154, 'Vikas Mishra', '1996-07-06', 'M', 'Diwakar Mishra', '8962548101', 'Lebad Chouki ,Dhar', 'DHAR', 454773, 0, 'N/A', 'IIMR INDORE', 1),
(155, 'Akash gautam', '1996-09-22', 'M', 'late Jagmohan gautam', '9111119334', '253\r\nJiwaji Nagar thatipur gwalior', 'Gwalior', 474011, 0, 'N/A', 'IIMR INDORE', 1),
(156, 'Parth Shukla', '2000-12-03', 'M', 'Y K Shukla', '9893010779', 'H.NO.62, GEETANJALI NAGAR, RAIPUR-492001', 'RAIPUR', 492009, 12, 'Science', 'KAANGER VALLEY ACADEMY ', 0),
(157, 'Varsha choudhary', '1997-03-15', 'F', 'Ugamraj choudhary', '8889638947', 'Jinsi chouraha indore', '452006', 452006, 0, 'N/A', 'Indore institute of management & research', 1),
(158, 'varsha choudhary', '1997-03-15', 'F', 'ugamraj choudhary', '8889638974', '39-arju palten jinsi chouraha ', 'indore', 452006, 0, 'N/A', 'IIMR INDORE', 1),
(159, 'Surbhi Dharpure', '1994-06-28', 'F', 'Yogeshwar Dharpure', '07987697022', 'Senior HIG 26 Housing board colony chhindwara ', 'Chhindwara', 731, 0, 'N/A', 'IIMR Indore', 1),
(160, 'BASANT JHA', '1994-01-01', 'M', 'BABULAL JHA', '7007407116', '371 shiv city Near Ips collage Indore', 'INDORE', 450086, 0, 'N/A', 'Indore insititute of managment & resurch Indore', 1),
(161, 'Harpreet Kaur Vasu', '1996-11-02', 'F', 'Pritpal Singh Vasu', '9827951264', '4/A Mani Avenue ,Vaishali Nagar, Flat no.304 ,Indore', 'Indore', 452009, 0, 'N/A', 'Indore institute of management and research', 1),
(162, 'RAHUL MEWARI', '1995-02-22', 'M', 'MAHESH KUMAR MEWARI', '9752058637', 'IN FRONT OF VEDANT SCHOOL, VISHWAKARMA NAGAR, NEAR FOOTI KOTHI INDORE', 'indore', 453331, 0, 'N/A', 'IIMR', 1),
(163, 'SHUBHAM PARIHAR', '1995-07-27', 'M', 'SHANTI LAL PARIHAR', '8982217350', '133 DAMODAR NAGAR DHAR ROAD INDORE', 'indore', 453331, 0, 'N/A', 'IIMR', 1),
(164, 'Kratika tripathi', '1997-03-21', 'F', 'Kartikey tripathi', '7047847400', '117c-special Gandhi nagar ', 'Indore', 453331, 0, 'N/A', 'Indore institute of Management and research', 1),
(165, 'Aneesha S pachpande', '1996-10-02', 'F', 'P. Sudhir laxman', '8982084950', 'Main road kodariya,mhow\r\n\r\n\r\n', 'Indore', 453441, 0, 'N/A', 'Indore institute of management and research', 1),
(166, 'Vidushi tiwari', '1995-07-14', 'F', 'Satish tiwari', '7697673478', '56 vidur nagar', 'Indore', 453331, 0, 'N/A', 'Indore institute of Management and research', 1),
(167, 'Saloni bhagat', '1996-12-22', 'M', 'Durga Shankar Bhagat', '7415995281', '301 B Indra sagar apartment  shiv sagar colony bijalpur indore', 'Indore', 452001, 0, 'N/A', 'Indore Institute of manangement and research', 1),
(168, 'Ayush malviya', '1994-11-03', 'M', 'Rambilas malviya', '7999577239', 'Bhola ram ustad marg Indore', ' Indore', 452001, 0, 'N/A', 'IIMR', 1),
(169, 'itansha raghuvanshi', '1997-03-31', 'F', 'mahesh raghuvanshi', '9039926546', '146-kanh kunj nagar airport road', 'indore', 452001, 0, 'N/A', 'IIMR INDORE', 1),
(170, 'Srajan tomar', '1997-05-31', 'M', 'Late shri satish singh tomar', '8770436685', '101 c block sanghvi residency bypass road', 'Indore', 452016, 0, 'N/A', 'Symbiosis university of applied sciences', 1),
(171, 'Kshitij Sanone ', '1997-11-12', 'M', 'Sanjay Sanone ', '8827956135', '108,desai bagar ', 'Ujjain ', 456001, 0, 'N/A', 'Lokmanya tilak science and commerce college ', 1),
(172, 'Kushal sheth', '1999-08-08', 'M', 'Rajiv sheth', '8770410849', '30 joy builders colony ,near saket', 'Indore', 452001, 0, 'N/A', 'SGSITS indore', 1),
(173, 'Gaurav sen', '1996-06-11', 'M', 'Dwarka Prasad sen', '8602524861', '32 Batalian  dewas road  Ujjain (M.P)', 'Ujjain ', 456010, 0, 'N/A', 'IIMR', 1),
(174, 'Aojas Wankhede', '2000-02-24', 'M', 'Kailash Wankhede', '9109329898', '196-B, Scheme no.134', 'Indore', 452010, 0, 'N/A', 'Z', 1),
(175, 'Nikita patidar', '1995-06-17', 'F', 'Mr.raj patidar', '9009113205', ' IIST girls hostel ,opp IIM, rau pithampur raod ', 'Indore', 452001, 0, 'N/A', 'Indore institute of management and research ', 1),
(176, 'Aayush Raghuwanshi', '1997-06-17', 'M', 'Santosh Raghuwanshi', '7748091967', 'Indra colony near kusum mahavidyalay .Banapura', 'Banapura', 475001, 0, 'N/A', 'ITM UNIVERSITY, Gwalior', 1),
(177, 'Ankur chadda', '1994-11-10', 'M', 'Ashok chadda', '9685481976', 'Rao Durga Colony', 'Indore', 452001, 0, 'N/A', 'Indore institution Management Research', 1),
(179, 'Siddharth Singh Chouhan', '2000-06-27', 'M', 'Chhagan Singh Chouhan', '8349232206', '259, vainktesh nagar\r\n(main), airport road, indore, madhya pradesh', 'Indore', 452010, 12, 'Science', 'Delhi Public School, Indore', 0),
(180, 'Ankit Soni', '1997-10-19', 'M', 'Vishnu Soni', '7692908069', '164/4 Sunder Hagar Sawer Road, Indore', 'Indore', 452001, 0, 'N/A', 'Symbiosis University Of Applied Sciences', 1),
(181, 'MAYANK KUMAR', '1999-11-12', 'M', 'SUBHASH CHANDRA SINGH', '9179171864', 'A-5 ground floor shubhajalipuram dd Nagar Gwalior', 'Gwalior', 474005, 0, 'N/A', 'MITS GWALIOR', 1),
(182, 'Gourav koushal', '2000-12-30', 'M', 'Rajesh koushal', '7000715878', 'Bhopal Mp railway station coach factory sai mandir gali no. 1', 'Bhopal', 462010, 11, 'Science', 'Rose mary high secondary school ', 0),
(183, 'Gourav Koushal ', '2000-12-30', 'M', 'Rajesh koushal ', '7000715878', 'Bhopal railway station near sai mandir ke pass gali no. 1', 'Bhopal ', 462010, 11, 'Science', 'Rose mary high secondary school ', 0),
(184, 'Swati joshi ', '1997-07-29', 'F', 'Mr. Vishnu Prasad joshi', '9039045235', '84 sukhdev Nagar ex2 airport road ', 'Indore', 453331, 0, 'N/A', 'Indore Institute of management and research ', 1),
(185, 'Meenakshi Chugh', '1995-12-25', 'F', 'Omprakash Chugh', '8962280249', '185, Dwarkapuri', 'Indore', 452009, 0, 'N/A', 'Indore institute of Management research', 1),
(186, 'aditya gupta', '1999-01-13', 'M', 'Giriraj Gupta', '9926686775', 'airport road', 'indore', 452001, 0, 'N/A', 'SUAS', 1),
(187, 'Uzma Khan', '1995-10-14', 'F', 'Dr. M. J. Khan', '8349500714', 'Sector I Green Park colony ,indore', 'Indore', 452001, 0, 'N/A', 'Indore institute of management and research', 1),
(188, 'Jamir Mulla', '1977-04-30', 'M', '', '9764978686', 'Geeta Bhavan Indore', 'Indore', 452010, 0, 'N/A', 'Prestige College', 1),
(189, 'Anushka Tirole', '2001-12-25', 'F', 'Sharad Tirole', '9977221747', '711-A Ashok nagar, Airport road ,Indore', 'Indore', 452005, 11, 'Science', 'Chameli devi public school', 0),
(190, 'Manasvi Dubey', '2002-04-13', 'F', 'Rahul Dubey', '7879352233', '445, B ashok nagar airport road', 'Indore', 452005, 11, 'Science', 'Chameli devi public school', 0),
(191, 'Shaily Lad', '2001-10-17', 'F', 'Subodh lad', '9406638757', '395,pallhar nagar near air port road, indore M.P (INDIA)', 'Indore', 452005, 11, 'Science', 'Shri Gujarati samaj A.M.N English medium school', 0),
(192, 'Vinamra Malu ', '1999-09-03', 'M', 'Ravish malu', '9479933028', 'B 503 Samvaxad Sonnet\r\nNear Tragad under bridge \r\n', 'Ahmedabad ', 382481, 0, 'N/A', 'Nirma university ', 1),
(193, 'T Janardhan Reddy', '1998-12-10', 'M', 'T Ramakrishna Reddy', '9491350611', 'GPREC', 'Kurnool', 518007, 0, 'N/A', 'GPREC', 1),
(194, 'Ashish Patidar', '1996-11-13', 'M', 'Krishna Patidar', '8358880362', '707, Dankan Road, Harsola, Mhow', 'Indore', 453441, 0, 'N/A', 'Indore Institute of Science and Technology', 1),
(195, 'Amit arora', '2003-11-21', 'M', 'S k arora', '9131617096', 'Chandra nagar', 'Indore', 452001, 11, 'Commerce', 'Iips', 0),
(196, 'Purnim Malu', '1999-03-31', 'M', 'Hemant Malu', '9977022210', '15/13, South Tukoganj ', 'Indore', 452001, 0, 'N/A', 'IIPS', 1),
(197, 'Paridhi Shewani', '1999-02-05', 'F', 'Sanjay Shewani', '7879003007', '\r\n159 Amitesh Nagar Schm no\r\n59', 'Indore', 452014, 0, 'N/A', 'International Institute of Professional Studies', 1),
(198, 'Kirti Jain', '2017-09-21', 'F', 'Kailash Jain', '9294548471', 'Old palasia ', 'Indore', 452001, 0, 'N/A', 'Inifd', 1),
(199, 'Roochin', '1998-12-05', 'M', 'Papa', '8089786789', 'jkg', 'iNDORE', 453331, 0, 'N/A', 'suas', 1),
(200, 'Rishab', '1987-12-01', 'M', 'Vinod', '9977725747', '271 Indore', 'Indore', 452012, 0, 'N/A', 'St Pauls', 1),
(201, 'Akash bairagi', '1999-11-06', 'M', 'Krishnakant bairagi', '9111117131', '141,vyanktesh nagar ext.  Near saint giri school airport road indore', 'Indore', 452005, 0, 'N/A', 'Suas', 1),
(202, 'Swati joshi', '1997-07-29', 'F', 'Vishnu Prasad joshi', '9039045235', '84 sukhdev nagar ', 'Indore', 453331, 0, 'N/A', 'Indore institute of Management and research', 1),
(203, 'Chayan Banasl', '2017-11-22', 'M', 'Ashok Bansal', '9644959600', 'HOMRE', 'INDORE', 453441, 0, 'N/A', 'SUAS', 1),
(204, 'abcde', '2017-12-31', 'O', 'abcde', '7654321987', 'abc', 'abc', 99999, 0, 'N/A', 'IIT', 1),
(205, 'bhavya punwani', '1999-08-13', 'F', 'sanjaypunwani', '8889087506', '9-d sea sardar nagar behind geeta bhawan temple', 'indore', 452001, 0, 'N/A', 'suas', 1),
(206, 'Raghvendra Shukla', '1997-12-07', 'M', 'Prafulla Shukla', '9179554893', 'C-202 Sagar Campus Chunabhatti Kolar Road ', 'Bhopal', 462017, 0, 'N/A', 'Sagar Institute of Research and Technology', 1),
(207, 'Yash Vijayvargiya', '1998-11-16', 'M', 'Anurag Vijayvargiya', '9301280450', '37 A Chhatrapati Nagar, ', 'Indore', 452001, 0, 'N/A', 'SUAS', 1),
(208, 'ABHISHEK BHATTACHARJEE', '2003-05-03', 'M', 'KANCHAN BHATTACHARJEE', '8827877332', 'chouhan green valley junwani bhilai ', 'bhilai', 490028, 11, 'Science', 'mgm senior secondary school bhilai', 0),
(209, 'Prachi Deshpande', '2000-04-10', 'F', 'Manojkumar', '7225871141', 'B-1203,BCM Paradise, nipania', 'indore', 452010, 11, 'Science', 'Prestige school', 0),
(210, 'Prashant patel', '2001-03-20', 'M', 'Kewalram patel', '9669569189', 'Kharkalan, khandwa', 'Khandwa', 452020, 12, 'Science', 'San Marino public School, Indore', 0),
(211, 'UMESH SABLOG ', '1999-10-27', 'M', 'GAJENDRA ', '9098244033', 'SAN MARINO SCHOOL CAMPUS', 'INDORE', 452020, 12, 'Science', 'SAN MARINO PUBLIC SCHOOL', 0),
(212, 'VAIBHAV DASHORE', '2001-04-17', 'M', 'sunil', '9755066783', 'BHAWSINGPURA KHANDWA', 'KHANDWA', 450001, 12, 'Science', 'SAN MARINO PUBLIC SCHOOL', 0),
(213, 'SAKSHI PATIDAR', '2001-05-10', 'F', 'MUKESH', '9009088400', 'RAU INDORE', 'INDORE', 452001, 11, 'Commerce', 'SAN MARINO PUBLIC SCHOOL', 0),
(214, 'SHRUTI PURE', '2001-06-20', 'F', 'DHARMENDRA', '9424051379', 'simrol indore', 'INDORE', 452020, 11, 'Commerce', 'SAN MARINO PUBLIC SCHOOL', 0),
(215, 'Anisha Rautela', '1997-08-27', 'F', 'Col HCS RAUTELA', '8376022101', 'D-1205\r\nZenith Express\r\nSector-77\r\nNoida(UP)', 'NOIDA (UP)', 201301, 0, 'N/A', 'AMITY UNIVERSITY', 1),
(216, 'Chayan Bansal', '1998-09-10', 'M', 'Ashok Bansal', '8080808080', 'Indore', 'Indore', 453441, 0, 'N/A', 'SUAS', 1);

-- --------------------------------------------------------

--
-- Structure for view `final_db`
--
DROP TABLE IF EXISTS `final_db`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `final_db`  AS  select `u`.`email_id` AS `email_id`,`u`.`score` AS `score`,`u`.`attempt_flag` AS `attempt_flag`,`ud`.`reg_id` AS `reg_id`,`ud`.`name` AS `name`,`ud`.`dob` AS `dob`,`ud`.`gender` AS `gender`,`ud`.`father_name` AS `father_name`,`ud`.`phone_no` AS `phone_no`,`ud`.`address` AS `address`,`ud`.`city` AS `city`,`ud`.`pincode` AS `pincode`,`ud`.`standard` AS `standard`,`ud`.`stream` AS `stream`,`ud`.`name_of_institution` AS `name_of_institution`,`ud`.`college_flag` AS `college_flag` from (`users` `u` join `user_detail` `ud`) where (`u`.`reg_id` = `ud`.`reg_id`) ;

-- --------------------------------------------------------

--
-- Structure for view `final_db2`
--
DROP TABLE IF EXISTS `final_db2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `final_db2`  AS  select `u`.`email_id` AS `email_id`,`u`.`score` AS `score`,`u`.`attempt_flag` AS `attempt_flag`,`u`.`reg_id` AS `reg_id`,`ud`.`name` AS `name`,`ud`.`dob` AS `dob`,`ud`.`gender` AS `gender`,`ud`.`father_name` AS `father_name`,`ud`.`phone_no` AS `phone_no`,`ud`.`address` AS `address`,`ud`.`city` AS `city`,`ud`.`pincode` AS `pincode`,`ud`.`standard` AS `standard`,`ud`.`stream` AS `stream`,`ud`.`name_of_institution` AS `name_of_institution`,`ud`.`college_flag` AS `college_flag` from (`user_detail` `ud` join `users` `u`) where (`u`.`reg_id` = `ud`.`reg_id`) ;

-- --------------------------------------------------------

--
-- Structure for view `new_attempts`
--
DROP TABLE IF EXISTS `new_attempts`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `new_attempts`  AS  select `u`.`email_id` AS `email_id`,`u`.`score` AS `score`,`u`.`attempt_flag` AS `attempt_flag`,`u`.`reg_id` AS `reg_id`,`ud`.`name` AS `name`,`ud`.`dob` AS `dob`,`ud`.`gender` AS `gender`,`ud`.`father_name` AS `father_name`,`ud`.`phone_no` AS `phone_no`,`ud`.`address` AS `address`,`ud`.`city` AS `city`,`ud`.`pincode` AS `pincode`,`ud`.`standard` AS `standard`,`ud`.`stream` AS `stream`,`ud`.`name_of_institution` AS `name_of_institution`,`ud`.`college_flag` AS `college_flag` from (`users` `u` join `user_detail` `ud`) where ((`u`.`reg_id` = `ud`.`reg_id`) and (`u`.`attempt_flag` = 1) and (dayofmonth(substr(`u`.`started_at`,1,10)) > 17)) ;

-- --------------------------------------------------------

--
-- Structure for view `reg_email`
--
DROP TABLE IF EXISTS `reg_email`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reg_email`  AS  select `users`.`email_id` AS `email_id` from `users` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `college_questions`
--
ALTER TABLE `college_questions`
  ADD PRIMARY KEY (`ques_id`);

--
-- Indexes for table `school_questions`
--
ALTER TABLE `school_questions`
  ADD PRIMARY KEY (`ques_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`reg_id`),
  ADD UNIQUE KEY `email_id` (`email_id`);

--
-- Indexes for table `user_detail`
--
ALTER TABLE `user_detail`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `college_questions`
--
ALTER TABLE `college_questions`
  MODIFY `ques_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `school_questions`
--
ALTER TABLE `school_questions`
  MODIFY `ques_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `reg_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_detail`
--
ALTER TABLE `user_detail`
  ADD CONSTRAINT `user_detail_ibfk_1` FOREIGN KEY (`reg_id`) REFERENCES `users` (`reg_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
