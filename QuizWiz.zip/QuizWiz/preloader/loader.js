window.addEventListener('load',function(){
    document.getElementById("preloader").style.display="none";
});

        