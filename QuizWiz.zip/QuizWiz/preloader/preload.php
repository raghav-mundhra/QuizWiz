<link rel="stylesheet" href="preloader/css/style.css">
<script src="preloader/loader.js"></script>
<div id="preloader">
<div id="loader"></div>
</div>


