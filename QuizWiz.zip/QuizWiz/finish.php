<?php
	session_start();
	if( (isset($_SESSION['score'])) AND (isset($_SESSION['reg_id'])) )
	{
		//do nothing
    }
    else{
        header('location: index.php');
    }
	$score=$_SESSION['score'];
	$percentage=(($score*100)/20);
	$name=$_SESSION['name'];
	$email=$_SESSION['email'];
    require("frontend_lib.php");
    
    session_destroy();
	?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Thank You!</title>
    <link href="https://fonts.googleapis.com/css?family=Cabin|Exo+2|Kanit|Muli|Open+Sans|Raleway|Roboto" rel="stylesheet">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <style>
        .lcontainer1{
            position: absolute;
            display: flex;
            justify-content:center;
            align-items:center;
            width: 100%;
            height: 100%;
            background: linear-gradient(to right,#4D418E,#8261FF);
            text-align:center;
        }
        .ltitle1{
            width: 100%;
            text-align: center;
            font-family: 'Roboto', sans-serif;
            font-size: 3rem;
            padding: 10px;
            font-weight: bold;
        }
        .result1{
            padding: 30px;
            width: 75%;
            border: 2px solid black;
            border-radius: 5px;
            background: linear-gradient(#DBD1FF,#F7F5FF,#FBF9FF);
        }
        .linfo1{
            font-size: 1.8rem;
        }
        .linfo1 .textdiv1{
            padding: 10px;
            color: black;
            font-family: 'Raleway', sans-serif;
            font-size: 2rem;
        }
        .flex1{
            font-weight: 600;
            display: flex;
            opacity: 0;
            align-items: center;
            width: 100%;
            height: 100%;
            justify-content: center;
            font-size: 1.8rem;
            animation: flex 300ms 1 ease-in-out;
            animation-delay: 1s;
            animation-fill-mode: forwards;
        }
        .progress1{
            margin: 10px;
            height: 40px;
            background: #E7E7E7;
            border-radius: 5px;
        }
        .progress-bar{
            background: linear-gradient(to right,#4D418E,#433685,#33257C,#271A6F,#1C115A);
            animation: onload 1800ms 1 ease-in-out;
		animation-fill-mode:forwards;
            border-radius: 5px;
        }

        .linfo1 .text1{
            padding: 10px;
            font-size: 2rem;
        }
        @keyframes onload{
            from{
                width: 0%;
            }
            to{
                width: <?php
                echo($percentage);
                ?>%; 
            }
        }
        @keyframes flex{
            from{
                opacity: 0;
            }
            to{
                opacity: 1;
            }
        }
        #demo{
            font-size: 2.5rem;
            font-weight: bold;
            text-align: center;
            color: red;
        }
        .textdiv1{
            font-size: 2rem;
            text-align: left;
        }
        @media (min-width:0px) and (max-width:768px){
            .textdiv1{
                width: 100%;
                font-size: 2rem;
            }
            }
            @media (min-width:769px) and (max-width:1024px){
                .textdiv1{
                width: 70%;
                font-size: 2.3rem;
            }
            }
            @media (min-width:1025px) and (max-width:1440px){
                .textdiv1{
                width: 60%;
                font-size: 2.3rem;
            }
            }
            @media (min-width:1441px){
            .textdiv1{
                width: 30%;
                font-size: 2.3rem;
            }
            }
     </style>
     
     <script>
        var i = 0;
        var txt = 'Thank You for participating in QuizWiz 2017! Come and be a part of this event on 24 & 25 November at SUAS Campus, Indore! --Quiz Master Mr. Tarang Gagneja (TATA Crucible Winner).';
        var speed = 50;
        
        function typeWriter() {
          if (i < txt.length) {
            document.getElementById("demo").innerHTML += txt.charAt(i);
            i++;
            setTimeout(typeWriter, speed);
          }
        }
        </script>

</head>
<body onload="typeWriter() ">
<?php
require("preloader/preload.php");
?>
   <?php
   $head = new head();
   $head->displayheader();
   $foot=new footer();
   $foot->disp_footer();
   ?>
    <div class="lcontainer1 ">
        <div class="result1 ">
            <div class="ltitle1">You've completed the Preliminary round!</div>
            <div class="ltitle1">Please close this browser window when done.</div>
            <div class="linfo1">
                <div class="textdiv1">Name: <?php echo($name);?></div>
                <div class="textdiv1">Email: <?php echo($email); ?></div>
                <div class="textdiv1">Your Score out of 20 is: <?php echo($score);?></div>
                <div class="progress1">
                    <div class="progress-bar" style="width:<?php echo($percentage);?>">
                        <span class="flex1"><?php echo($percentage);?>%</span>
                    </div>
                </div> 
                <div class="text1"><p id="demo"></p></div>
                <div style='width:100%; text-align:center; font-size:3rem; font-weight:bolder; '><button class='btn btn-info'  onclick='window.open("http://www.suas.ac.in","_self")'>EXIT</button> </div>
                
                
        </div>
    </div>
    </div>
</body>
</html>
