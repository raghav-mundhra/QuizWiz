<?php 



class input_field
{
	function display($id, $class, $type/*password or text or email*/, $name, $placeholder, $required_flag/*0 or 1 */ )
	{
		if($required_flag==1)
		{
			echo "<input id='$id' class='$class' type='$type' name='$name' placeholder='$placeholder' required>";
		}
		else
		{
			echo "<input id='$id' class='$class' type='$type' name='$name' placeholder='$placeholder'>";
		}
	}
	function display_w_js($id, $class, $type/*password or text or email*/, $name, $placeholder, $required_flag/*0 or 1 */,$funcin,$funcout )
	{
		if($required_flag==1)
		{
			echo "<input id='$id' class='$class' type='$type' name='$name' placeholder='$placeholder' required onfocus='$funcin' onfocusout='$funcout'>";
		}
		else
		{
			echo "<input id='$id' class='$class' type='$type' name='$name' placeholder='$placeholder' onfocus='$funcin' onfocusout='$funcout'>";
		}
	}
}

class quiz_option
{
	function display($id, $value, $checked_flag/*0 or 1 */ )
	{
		if($checked_flag==1)
		{
			echo "<input type='radio' name='option' value='$value' checked>";
		}
		else if($checked_flag==0)
		{
			echo "<input id='$id' type='radio' name='option' value='$value'>";
		}
	}
}
class input_button
{
	function display($id,$class,$type,$name,$onclick,$value)
	{
		echo "<input id='$id' class='$class' type='$type' name='$name' onclick='$onclick' value='$value'>";
	}
	function display_btn($id,$class,$type,$name,$onclick,$value)
	{
		echo "<button id='$id' class='$class' type='$type' name='$name' onclick='$onclick'>$value</button>";
	}
	function disp_btn_bs($id,$class,$type,$name,$onclick,$value,$data_tg,$data_tog)
	{
		
		echo('<button class="'.$class.'" data-toggle="'.$data_tog.'" data-target="'.$data_tg.'" onclick="'.$onclick.'">'.$value.'</button>');
	}
}

class input_check
{
	private $value;
	public function input_safe($conn,$post_input)
	{
		$this->value = (mysqli_real_escape_string($conn,htmlspecialchars(strip_tags($post_input))));
		
		return $this->value;
	}
}



class form
{

	function display($form_id,$form_class,$id_1,$class_1,$id_2,$class_2,$button_id,$button_class)
	{
	}
	 
}


class form_receive
{
	 public function login()
	{
		
	}
}

class useroptions{
	function display(){
		$button1=new input_button();
		$button2=new input_button();
		$button3=new input_button();
		echo('
		<form action="" method="post">
			  <div class="cr_container">
			  <div class="cr_restrict">
					 ');
				 $button1->display_btn("border-div","course","submit","","",'Generate Marksheet <i class="glyphicon glyphicon-copy" style="margin-left: 10px;"></i>');
				 $button1->display_btn("border-div","course","submit","","",'Feed Marks <i class="glyphicon glyphicon-download-alt" style="margin-left: 10px;"></i>');
				 $button1->display_btn("border-div","course","submit","","",'View Marks <i class="glyphicon glyphicon-eye-open" style="margin-left: 10px;"></i>');			 
			  echo('</div>
			  </div>
			  </form>');
	}
}
class dashboard{
	function display(){
		echo('<div id="custom-bootstrap-menu" class="navbar navbar-default " role="navigation">
		<div class="container-fluid">
			<div class="navbar-header"><a class="navbar-brand" href="#">Welcome, <b>'.$_SESSION['operator_name'].'</b></a>
				
			</div>
			
				<ul class="nav navbar-nav navbar-right">
				<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Options <span class="caret"></span></a>
				<ul class="dropdown-menu">
				  <li><a href="#">Change Password</a></li>
				  <li><a href="#">Update Details</a></li>
				  <li><a href="#">Sign Out</a></li>
				</ul>
			  </li>
			  <li><a href="mailto:test@xyz.com"><i class="glyphicon glyphicon-envelope" style=""></i> Contact Super Admin</a></li>
				</ul>
			
		</div>
	</div>');
	}
}
class attempt{
	function display($ques_no,$ques,$option1,$option2,$option3,$option4){
		$button=new input_button();
		$rdb=new input_field();
				echo('<div class="qcontainer col-sm-12">
				<div class="well well-lg col-sm-8 rightcontainer">
					<div class="q">
						Q['.$ques_no.'] '.$ques.'
					</div>
					<div class="options">
						<div class="opt">');
						$rdb->display("","","option","rdb","","");
						echo(' '.$option1.'</div>
						<div class="opt">');
						$rdb->display("","","option","rdb","","");
						echo(' '.$option2.'</div>
						<div class="opt">');
						$rdb->display("","","option","rdb","","");
						echo(' '.$option3.'</div>
						<div class="opt">');
						$rdb->display("","","option","rdb","","");
						echo(' '.$option4.'</div>
					</div>
					<div class="footernav">
					<form action="" method="post">
						');
						$button->display_btn("","prev remove","submit","prev","",'<i class="glyphicon glyphicon-arrow-left" id="left"></i> Previous');
						$button->display_btn("","remove","submit","flag","",'<i class="glyphicon glyphicon-flag"></i> Flag');		
						$button->display_btn("","next remove","submit","next","",'Next <i class="glyphicon glyphicon-arrow-right" id="right"></i>');		
						echo('
						</form>
						</div>
				</div>');
			
			
				$this->display_nav(10);
			
		
		
	}
	function display_nav($n){
		$button=new input_button();
		echo('<div class="well well-lg  col-sm-4">
		<div class="timer">
			00:30:00
		</div>
		<div class="navigation">');
		for($i=1;$i<=$n;$i++){
			
			$button->display("","navopt","submit","","",$i);
			
		}
		echo('</div>
		</div>
	</div>');
	}
}
class validate{
	function conf_logged_in(){
		if(!isset($_SESSION['operator_id'])){
			header('location:index.php');
		}
	}
}

/*class course_backend
{
	function execute($conn)
	{
		$course_query="SELECT * FROM courses";
		$c_q_run=mysqli_query($conn,$course_query);
		var i=0;
		for(i; i<mysqli_num_rows($c_q_run); i++)
		{
			$courses=mysqli_fetch_assoc($)
			if(isset($_POST['submit']))
			{
				if($_POST['name']==$cid)
				{
					
				}
			}
		}
			
		
	}
}*/

