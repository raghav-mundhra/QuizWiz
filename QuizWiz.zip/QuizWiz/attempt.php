<?php
session_start();
if(isset($_SESSION['reg_id']))
{
    //do nothing
}
else{
    header('location: index.php');
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Attempt Quiz</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
<?php
require("preloader/preload.php");
?>
    <?php
    require("config.php");
    require("frontend_lib.php");
    require("class_lib.php");
    require("test_classes.php");
    $header=new head();
    $uptime=new uptime();
    $header->displayheader();    

    $initial = new initial();
    $initial->initialise($conn);
    $uptime->time_up($conn);
	$uptime->submit_ALL($conn);
    $click=new click();
    $click->next_prev_submit($conn);
    $footer=new footer();
    $footer->disp_footer();
    ?>    
  <!-- Modal -->
  
</body>
</html>
