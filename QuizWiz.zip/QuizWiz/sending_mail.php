<?php
require_once("alert.php");
// USES  $email,$name,$send_pass
        // Import PHPMailer classes into the global namespace
        // These must be at the top of your script, not inside a function
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\Exception;
        //Load composer's autoloader
        require 'vendor/autoload.php';

        $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
        try {
            //Server settings
            //$mail->SMTPDebug = 1;                                 // Enable verbose debug output	//DELETE THIS
            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';  					  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'suas.quizwiz2017@gmail.com';                 // SMTP username
            $mail->Password = 'scrn0812@suas';                           // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to

            //Recipients
            $mail->setFrom('suas.quizwiz2017@gmail.com', 'Technical Team');         //CHANGE MAIL ID
            $mail->addAddress($email, $name);     // Add a recipient
            //$mail->addAddress('ellen@example.com');               // Name is optional
            $mail->addReplyTo('suas.quizwiz2017@gmail.com', 'Technical Team'); //CHANGE MAIL ID
            //$mail->addCC('cc@example.com');
            //$mail->addBCC('bcc@example.com');

            //Attachments
            //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
            //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

            //Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'QuizWiz-Registration Confirmation';
            $mail->Body    = Mail_text($email,$send_pass,$name);
            $mail->AltBody = strip_tags(Mail_text($email,$send_pass,$name));
            $mail->send();
            $alert=new alert();
            $alert->success_exec("Thank You for registering with QuizWiz 2017! A mail containing your login details has been sent to your registered email ID.<br>Please check your email for confirmation!","success");
            
        } catch (Exception $e) {
            $alert=new alert();
            $alert->exec("There was a problem sending email to your registered ID!<br>Mailer Error:". $mail->ErrorInfo,"danger","105","suas.quizwiz2017@gmail.com");
        }

    function Mail_text($email,$password,$name){
		$mail="";
		//require("frontend_lib.php");
        $mail.='
        <html>
        <head>
        <style>
        '."
        
	body
        {
            text-align:center;
        }
        .menu-contain{
            position: fixed;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            right: 0px;
            height: 80vh;
        }
        .title{
            font-size: 28px;
            color: white;
            text-transform: uppercase;
            font-weight: 400;
        }
        .container{
            font-size: 22px !important;
            width: 100%!important;
            min-height: 70px!important;
            padding: 5px!important;
            display: flex;         /* establish flex container */
            flex-direction: row;            /* default value; can be omitted */
            flex-wrap: nowrap;              /* default value; can be omitted */
            justify-content: space-around; /* switched from default (flex-start, see below) */
            background: rgba(41, 29, 100 ,0.7);
            font-family: 'Open Sans', sans-serif;
            align-items: center;
            margin: 0;
        }
        .mailcontainer{
            font-size: 24px !important;
            width: 100%!important;
            min-height: 70px!important;
            padding: 5px!important;
            display: flex;         /* establish flex container */
            flex-direction: row;            /* default value; can be omitted */
            flex-wrap: nowrap;              /* default value; can be omitted */
            justify-content: space-around; /* switched from default (flex-start, see below) */
            background: rgba(41, 29, 100 ,0.8);
            font-family: 'Open Sans', sans-serif;
            align-items: center;
            margin-bottom:30px;
        }
        .logo img{
            height: 70px;
        }
        .text{
            font-family: 'Raleway', sans-serif;
            font-size: 16px;
            font-weight: 200;
            color: white;
            
        }
        #menu_span{
            opacity: 0;
            display: none;
            transition: all 300ms ease-in-out;
        }
        a:hover{
            color: #B1C3F8;  
            text-decoration: none;
        }
        .item:hover #menu_span{
            display: block;
            opacity: 0;
            animation: appear 300ms ease-in-out;
            animation-fill-mode: forwards;
        }
        @keyframes appear{
            from{
                opacity: 0;
            }
            to{
                opacity: 1;
            }
        }
        a{
            text-decoration: none;
            color: inherit;
            transition: all 300ms ease-in-out;
        }
        @keyframes easeleft{
            from{
                transform: translateX(70px);
            }
            to{
                transform: translateX(0px);
            }
        }
        .item{
            padding: 5px;
            margin: 10px;
            line-height: 20px;
            color: white;
            font-size: 2.4rem;
            text-align: center;
        }
        .footer {
            background: rgba(41, 29, 100 ,0.7);
            position: fixed;
            display: flex;                  /* establish flex container */
            flex-direction: row;            /* default value; can be omitted */
            flex-wrap: nowrap;              /* default value; can be omitted */
            justify-content: space-between;
            align-items: center;
            height: 8rem;
            width: 100%;
            padding: 5px;
            color: white;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
            bottom: 0;
            font-family: 'Raleway', sans-serif;
        }
        
        .uni_name {
            font-size: 2rem;
            font-weight: bolder;
            margin-left: 15px;
        }
        
        .copyright {
            font-size: 2rem;
        }
        
        .developers {
            margin-right: 15px;
            font-size: 2rem;
            float: right;
            right: 0px;
        }
        
        .developers a {
            color: inherit;
            font-family: century gothic;
            font-weight: bolder;
            transition: 300ms;
        }
        .developers a:hover {
            color: #B1C3F8;
            transition: 300ms;
            font-size: 2.1rem;
        }
        .uni_name a {
            color: inherit;
            font-family: century gothic;
            font-weight: bolder;
            transition: 300ms;
        }
        .uni_name a:hover {
            color: #B1C3F8;
            transition: 300ms;
            font-size: 2.1rem;
        }
        .pcontain{
            left: 0;
            top: 20%;
            display: flex;
            position: absolute;
            width: 100%;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        .name{
            font-family: 'Muli', sans-serif;
            font-size: 40px;
            color: black;
            font-weight: bold;
            text-decoration:underline;
padding:15px;
width:100%;
        }
        .button{
            margin: 10px;
            padding: 10px;
        }
        
        #disabled{
            pointer-events:none;
            opacity: 0.6;
        }
        #disabled:focus{
            outline-width: 0;
        }
        #disabled:hover{
            cursor: inherit;
            background: transparent;
            color: black !important;
        }
        .dateinfo{
            font-size: 30px;
            font-weight: bolder;
            text-align: center;
            color: black;
            font-family: 'Raleway', sans-serif;
            padding: 10px;
            padding-top: 40px;
        }
        .dateinfo::selection{
            color: red;
        }
        .info{
            text-align:center;
            font-family: 'Open Sans', sans-serif;
            font-size:20px;
            line-height: 35px;
          }
        .dateinfo1{
            font-size: 30px;
            font-weight: bolder;
            text-align: center;
            color: black;
            font-family: 'Raleway', sans-serif;
            padding: 10px;
            padding-top: 15px !important;
        }
        .dateinfo1::selection{
            color: red;
        }
        .details{
            margin: 10px;
            padding: 10px;
            border: 2px dashed black;
            font-weight:bolder;
            font-family: 'Open Sans', sans-serif;
            text-decoration:none;
        }
        .inforem{
            text-decoration: underline;
        }
        .infomail{
            text-align: left;
            font-family: 'Open Sans', sans-serif;
            font-size:20px;
            line-height: 35px;
        }
        .infolast{
            text-align: left;
            font-family: 'Open Sans', sans-serif;
            font-size:16px;
            line-height: 35px;        
        }
        ".'</style>
        </head>
        <body>
        <div class="mailcontainer">
        <div class="title">SYMBIOSIS UNIVERSITY OF APPLIED SCIENCES</div>
        </div>
        <div class="pcontain">
			 
             <div class="button">
             
				 <div class="info">
<div class="name" >
             Quiz Wiz 2017
            </div>
Dear '.$name.', 	
Greetings from Symbiosis University of Applied Sciences!<br>
					Thank You for registering with QuizWiz, 2017.
				<div class="inforem">
					Please use the following details to attempt the quiz:
				</div>
				<div class="details">
                Username: '.
                $email.'<br> 
				Password: '.$password.' 
				</div>   
				</div>
                <div class="dateinfo1">Prelims on Nov 17, 2017</div>
                <div class="dateinfo1">Top 4 students from each institution will be selected for the second round!</div>
                <div class="dateinfo1" style="text-align:left">Points to remember:</div> 
                <div ><ul type="square">
                <li><div class="infomail">Use Google Chrome web browser for better performance.</div></li>
<li><div class="infomail">Do not leave the browsing screen while attempting the quiz.</div></li>
                <li><div class="infomail">There is one and only one attempt available for the quiz.</div></li> 
 <li><div class="infomail">Every question carries one mark.</div></li> 
<li><div class="infomail">There is no negative marking.</div></li>
<li><div class="infomail">25 minutes will be alloted per attempt.</div></li>  
                <li><div class="infomail">The quiz timer will start as soon as you login on 17th November 2017.</div></li>
<li><div class="infomail">Please remember the points mentioned above.</div></li>  
                <li><div class="infomail">For any technical queries please contact the following:
					<a href="mailto:suas.quizwiz2017@gmail.com">Technical Team (suas.quizwiz2017@gmail.com).</a></li></ul>
                    </div>
                <div class="infolast">NOTE: <ol><li>Please retain this mail for reference.</li>
<li>Please make sure to reproduce proof of your identification as per details filled during registration.</li></ol></div>
				</div>
		 </div>
        </body>
        </html>';
		return $mail;
	}

?>