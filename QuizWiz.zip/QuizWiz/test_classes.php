<?php 

// READ ME 
// confirm the number of the questions and time per test// Assumed values: questions=20 and time=30min=1800 seconds.
// maximum marks assumed here is 20.
// initialisation of certain SESSION variables like start_stamp and start_flag on the event of clicking of register button.


class attempt_now			//MOVE THIS CLASS TO test_class.php FILE.
{
	function execute($conn)
	{
		if(isset($_POST['attempt_now']))		//CHECK THE NAME OF THE INPUT_BUTTON IN THE INDEX PHP FOR RECEIVING BY $_POST['attempt_now']
		{
			//echo("12345667");
			require_once("alert.php");
			require_once('class_lib.php');
			$injection_check = new input_check();
			$email=$_POST['email'];
			$pass=$_POST['password'];			
			$password=md5($pass);
			
			$authenticate_query="SELECT reg_id, attempt_flag FROM users WHERE email_id='$email' AND password='$password'";
			$authenticate_query_run=mysqli_query($conn,$authenticate_query);
			$authenticate_query_result=mysqli_fetch_assoc($authenticate_query_run);
			$reg_id=$authenticate_query_result['reg_id'];
			$auth_query2="SELECT college_flag,name FROM user_detail where reg_id=$reg_id";
			if($authenticate_query_run){
				$auth_query2_run=mysqli_query($conn,$auth_query2);
				if($auth_query2_run){
					$auth_query2_run_result=mysqli_fetch_assoc($auth_query2_run);
				}
				
			}
			
			
			if($authenticate_query_run AND $auth_query2_run)
			{
				
				$attempt_flag=$authenticate_query_result['attempt_flag'];
				
				$_SESSION['attempt_flag']=$attempt_flag;
				if($attempt_flag==1)
				{
					session_destroy();
					$alert=new alert();	
					$alert->success_exec("You have already attempted the quiz!","warning");
				}
				else
				{
					
					$_SESSION['start_flag']=0;
					$reg_id=$authenticate_query_result['reg_id'];
					$_SESSION['reg_id']=$reg_id;
					$college_flag=$auth_query2_run_result['college_flag'];
					$_SESSION['college_flag']=$college_flag;
					
					$update_attempt_flag="UPDATE users SET attempt_flag=1 WHERE reg_id=$reg_id";
					$update_attempt_flag_run = mysqli_query($conn,$update_attempt_flag);
					if($update_attempt_flag_run){
						$_SESSION['email']=$email;
						$_SESSION['name']=$auth_query2_run_result['name'];
						header('location: attempt.php'); //CHECK THE test_classes.php FILE FOR THE USE OF THESE SESSION VARIABLES
					}
					else{
						session_destroy();
						header('location: index.php');
					}
				}
			}
			else
			{
				$alert=new alert();
				$alert->exec("Invalid Credentials!","danger","110","suas.quizwiz2017@gmail.com");
			}
		}
	}
}



class initial
{
	function initialise($conn)
	{
		
/*		if(isset($_SESSION['start_flag'])){
			//do nothing
		}
		else{
			$_SESSION['start_flag']=0;
		}*/ //to be deleted
		//echo($_SESSION['start_flag']);
		//if($_SESSION['start_flag']==0) //initialise this session variable at the time when the user clicks the register button!
		echo('<script>
		function triggerSubmit(){
			 document.getElementById("khatam").click();
		}
	 
	  function startTimer(){
		
		if(typeof(Storage)!=undefined){
		  if(sessionStorage.timeLeft==null){
			var presentTime = document.getElementById("timer").innerHTML;
		var timeArray = presentTime.split(/[:]+/);
		var m = timeArray[0];
		var s = checkSecond((timeArray[1] - 1));
		if(s==59){m=m-1}
		if(m<0){alert("timer completed")}
		document.getElementById("timer").innerHTML =
		  m + ":" + s;
		setTimeout(startTimer, 1000);
		var time={min:m, sec:s};
		sessionStorage.timeLeft=JSON.stringify(time);
		console.log(sessionStorage.timeLeft);
		  }
		  else{
		  var time=JSON.parse(sessionStorage.timeLeft);
		  minutes=time.min;
		  seconds=time.sec;
		  if(minutes=="0" && seconds=="00"){
			document.getElementById("khatam").click();
		  }
		  else{
			var t=JSON.parse(sessionStorage.timeLeft);
			var presentTime=t.min+":"+t.sec;
			var timeArray = presentTime.split(/[:]+/);
			var m = timeArray[0];
			var s = checkSecond((timeArray[1] - 1));
			if(s==59){m=m-1}
			document.getElementById("timer").innerHTML =
			  m + ":" + s;
			setTimeout(startTimer, 1000);
			var time={min:m, sec:s};
			sessionStorage.timeLeft=JSON.stringify(time);
			console.log(sessionStorage.timeLeft);
			}
		  
		  }
		}
		else
		{
			alert("Your browser does not meet the requirements");
		}
	  }
	  
	  function checkSecond(sec) {
		if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
		if (sec < 0) {sec = "59"};
		return sec;
	  }
		  
	  </script>');
		
		
		if($_SESSION['attempt_flag']==0)
		{
			$_SESSION['start_time']=time();
			$_SESSION['total_marks']=0;
			$total_question=range(1,100);
			$req_shuffled=$total_question;
			shuffle($req_shuffled);
			for($i=1;$i<=20;$i++)     //taking top 20 questions from the suffled list
			{
				$ques_list[$i]=$req_shuffled[$i];
			}
			
			$_SESSION['pointer']=1; //initially
			$_SESSION['question_list']=$ques_list;
			$_SESSION['current_question']=$_SESSION['question_list'][$_SESSION['pointer']];
			$_SESSION['attempt_flag']=1;
			$reg_id=$_SESSION['reg_id'];
			$attempt_flag_query="UPDATE users SET attempt_flag=1 WHERE reg_id=$reg_id";
			$attempt_flag_query_run=mysqli_query($conn,$attempt_flag_query);
			//College OR SCHOOL
			 // taken Value of $_SESSION['college_flag'] its value while receiving the form
			
			if($_SESSION['college_flag']==1)
			{
				$_SESSION['question_table']='college_questions';
			}
			else
			{
				$_SESSION['question_table']='school_questions'; 
			}
			
			$i=1;
			foreach($ques_list as $question){
				$correct_opt_query="SELECT correct_opt from ". $_SESSION['question_table']." WHERE ques_id=".$question;
				$correct_opt_query_run=mysqli_query($conn,$correct_opt_query);
				if($correct_opt_query_run)
				{
					$row=mysqli_fetch_assoc($correct_opt_query_run);
					$_SESSION['correct_opt'.$i]=$row['correct_opt'];
					$i++;
				}
			}
			//Flagged questions for reconsideration
			for($i=1;$i<=20;$i++) //generating a session variable for each corresponding question
			{
				$_SESSION['question_flag'.$i]=0;	//if value is one then it means the user has marked this question for reconsideration
			}
			//$correct_option_query="SELECT correct_opt from ".$_SESSION['question_table']."WHERE ";
			//These are 20 session variables containing the option marked by the user//initially '0' meaning unmarked
			for($i=1;$i<=20;$i++)
			{
				$_SESSION['option_marked'.$i]=0; 
				
			}
			
		}
	}
}

class uptime
{
	/*function execute($conn)
	{
		$now = new DateTime();
		$current=$now->getTimestamp();
		$reg_id=$_SESSION['reg_id'];
		$get_stamp="SELECT started_at FROM users WHERE reg_id=$reg_id";
		$get_stamp_run=mysqli_query($conn,$get_stamp);
		$stamp = mysqli_fetch_assoc($get_stamp_run);
		$_SESSION['start_stamp']=$stamp['started_at'];
		//echo "123TATATA";
		//echo(strtotime("now"));
		if((strtotime('now')-strtotime($_SESSION['start_stamp']))>1500) //take value of $_SESSION['start_stamp'] from database or when the user clicks the regioster button!!
		{
			$_SESSION['total_marks']=0;
			for($i=1;$i<=20;$i++) //chanhe to 20!!
			{
				if($_SESSION['option_marked'.$i]==$_SESSION['corect_opt'.$i])  
				{
					$total=$_SESSION['total_marks'];
					$total+=1;
					$_SESSION['total_marks']=$total;
				}
			}
			$score=$_SESSION['total_marks'];
			$reg_id=$_SESSION['reg_id'];
			$feed_marks="INSERT INTO users(score) VALUES($score) WHERE reg_id=$reg_id";
			$feed_run=mysqli_query($conn,$feed_marks);
			if($feed_run==TRUE)
			{
				$_SESSION['score']=$score;
				header('location: finish.php');
			}
		}
	}*/
	function time_up($conn)
	{
		if(time()-$_SESSION['start_time']>=1600)
		{
			$total=0;
			for($i=1;$i<=20;$i++)
			{
				if($_SESSION['option_marked'.$i]==$_SESSION['correct_opt'.$i])  
				{
					$total+=1;
				}
			}
			$_SESSION['total_marks']=$total;
			$total_marks=$_SESSION['total_marks'];
			$reg_id=$_SESSION['reg_id'];
		//	echo $_SESSION['reg_id'];
		//	echo $total_marks;
			$marks_query="UPDATE users SET score=".$total_marks." where reg_id=".$reg_id;
			$marks_query_run=mysqli_query($conn,$marks_query);
			if($marks_query_run){
				$_SESSION['score']=$total_marks;
				header("location: finish.php");
			}
			else{
				require_once("alert.php");
				$alert=new alert();
				$alert->exec("Unable to submit Quiz! Please try again..","danger","107","suas.quizwiz2017@gmail.com");
			}
		}
	}
	
	function submit_ALL($conn)
	{
		$temp_pointer=$_SESSION['pointer'];
		if(($temp_pointer==1 AND isset($_POST['prev'])) OR ($temp_pointer==20 AND isset($_POST['next'])))
		{
			$_POST=array();
		}
		if(isset($_POST['submit']) /*OR $_SESSION['start_flag']==1*/)
		{
			if(isset($_POST['option']))
			{
				$option_marked=$_POST['option'];
				$_SESSION['option_marked'.$_SESSION['pointer']]=$option_marked; //storing the option marked in the session variable
			}
			else if(!isset($_POST['option']))
			{
				//nothing to be done// As already '0' is fed in the begining in the corresponding session variables
			}
		}
		if(isset($_POST['submit']))
		{
			$total=0;
			for($i=1;$i<=20;$i++)
			{
				if($_SESSION['option_marked'.$i]==$_SESSION['correct_opt'.$i])  
				{
					$total+=1;
					
				}
			}
			$_SESSION['total_marks']=$total;
			$total_marks=$_SESSION['total_marks'];
			$reg_id=$_SESSION['reg_id'];
		//	echo $_SESSION['reg_id'];
		//	echo $total_marks;
			$marks_query="UPDATE users SET score=".$total_marks." where reg_id=".$reg_id;
			$marks_query_run=mysqli_query($conn,$marks_query);
			if($marks_query_run){
				$_SESSION['score']=$total_marks;
				header("location: finish.php");
			}
			else{
				require_once("alert.php");
				$alert=new alert();
				$alert->exec("Unable to submit Quiz! Please try again..","danger","107","suas.quizwiz2017@gmail.com");

			}
		}
	}
}

class click
{
	private $ques_no;
	private $ques;
	private $option1;
	private $option2;
	private $option3;
	private $option4;
	
	
	function next_prev_submit($conn)
	{
		require_once('config.php');
		/*$check_uptime = new uptime;
		$check_uptime->execute($conn);*/ //To be replaced
		$temp_pointer=$_SESSION['pointer'];
		if(($temp_pointer==1 AND isset($_POST['prev'])) OR ($temp_pointer==20 AND isset($_POST['next'])))
		{
			$_POST=array();
		}
		if(isset($_POST['next']) OR isset($_POST['prev']) OR isset($_POST['navbtn']) OR isset($_POST['flag']) /*OR $_SESSION['start_flag']==1*/)
		{
			if(isset($_POST['option']))
			{
				$option_marked=$_POST['option'];
				$_SESSION['option_marked'.$_SESSION['pointer']]=$option_marked; //storing the option marked in the session variable
				
				
			}
			else if(!isset($_POST['option']))
			{
				//nothing to be done// As already '0' is fed in the begining in the corresponding session variables
			}
		}
		if(isset($_POST['next']))
		{	
			$pointertemp=$_SESSION['pointer'];
		//	echo($pointertemp);
			$pointertemp++;
		//	echo($pointertemp);
			$_SESSION['pointer']=$pointertemp;
		//	echo($_SESSION['pointer']);
			$_SESSION['current_question']=$_SESSION['question_list'][$_SESSION['pointer']];
	
		}
		else if(isset($_POST['prev']))
		{
			$pointertemp=$_SESSION['pointer'];
			$pointertemp--;
			$_SESSION['pointer']=$pointertemp;
			$_SESSION['current_question']=$_SESSION['question_list'][$_SESSION['pointer']];
		}
		else if(isset($_POST['navbtn']))
		{
			$pointertemp=$_POST['navbtn'];
			$_SESSION['pointer']=$pointertemp;
			$_SESSION['current_question']=$_SESSION['question_list'][$_SESSION['pointer']];
		}
		if(isset($_POST['flag']))
		{
			if($_SESSION['question_flag'.$_SESSION['pointer']]==0)
			{
				$_SESSION['question_flag'.$_SESSION['pointer']]=1;
			//	echo ($_SESSION['question_flag'.$_SESSION['pointer']]);
			}
			else if($_SESSION['question_flag'.$_SESSION['pointer']]==1)
			{
				$_SESSION['question_flag'.$_SESSION['pointer']]=0;
			}
		}
		$ques_id=$_SESSION['current_question'];
		$question_table=$_SESSION['question_table'];
	//	echo $question_table." ".$ques_id; 
		$ques_query="SELECT * FROM $question_table WHERE ques_id=$ques_id";
		$query_run=mysqli_query($conn,$ques_query);
		if($query_run){
			$ques_detail=mysqli_fetch_assoc($query_run);
			$this->ques_no=$_SESSION['pointer'];
			$this->ques=$ques_detail['question'];
			$this->option1=$ques_detail['option1'];
			$this->option2=$ques_detail['option2'];
			$this->option3=$ques_detail['option3'];
			$this->option4=$ques_detail['option4'];
			$_SESSION['correct_opt'.$_SESSION['pointer']]=$ques_detail['correct_opt'];// Here, a session variable for each coorespondin question will be created which will be storing its correct answer so that finally the option_marked and the coorect_option can be checked for totalling
			//echo($_SESSION['correct_opt'.$_SESSION['pointer']]);
			$temp_show=$_SESSION['correct_opt'.$_SESSION['pointer']];
			//echo($temp_show); 
			$this->display();
			 //deleted
		}
		else{
			echo("Error!"); //put alert box
		}
	}
	function display(){
		$button=new input_button();
		$rdb=new quiz_option();
				echo(' <form action="" method="post">
				<div class="qcontainer col-md-12">
				<div class="well well-lg col-md-8 rightcontainer">
				
					<div class="q">
						Q'.$this->ques_no.') '.$this->ques.'
					</div>
					<div class="options">
						<div class="opt">');

						$checked=$_SESSION['option_marked'.$_SESSION['pointer']];
						//FOR OPTION 1
						if($checked==1)
						{
							$rdb->display("", 1, 1 );
							echo(' '.$this->option1.'</div>
							<div class="opt">');
						}
						else
						{
							$rdb->display("", 1, 0 );
							echo(' '.$this->option1.'</div>
							<div class="opt">');
						}
						//FOR OPTION 2
						if($checked==2)
						{
							$rdb->display("", 2, 1 );
							echo(' '.$this->option2.'</div>
							<div class="opt">');
						}
						else
						{
							$rdb->display("", 2, 0 );
							echo(' '.$this->option2.'</div>
							<div class="opt">');
						}

						//FOR OPTION 3
						if($checked==3)
						{
							$rdb->display("", 3, 1);
							echo(' '.$this->option3.'</div>
							<div class="opt">');
						}
						else
						{
							$rdb->display("", 3, 0 );
							echo(' '.$this->option3.'</div>
							<div class="opt">');
						}

						//FOR OPTION 4
						if($checked==4)
						{
							$rdb->display("", 4, 1 );
							echo(' '.$this->option4.'</div>
							<div class="opt">');
						}
						else
						{
							$rdb->display("", 4, 0 );
							echo(' '.$this->option4.'</div>
							<div class="opt">');
						}

					echo('</div>
					
					<div class="footernav">
						');
						echo('<div>');
						$temp_pointer=$_SESSION['pointer'];	
						if($temp_pointer>1)
						{
							$button->display_btn("","prev remove","submit","prev","",'<i class="glyphicon glyphicon-arrow-left" id="left"></i> Previous');	
						}
						echo('</div>');
						echo('<div>');$button->display_btn("","remove","submit","flag","",'<i class="glyphicon glyphicon-flag"></i> Flag/Unflag');		
						echo('</div>');
						
						if($temp_pointer>=20)
						{
							echo('<div>');
							
						}
						else
						{
							echo('<div>');$button->display_btn("","next remove","submit","next","",'Next <i class="glyphicon glyphicon-arrow-right" id="right"></i>');		
						}

						
						
						echo('</div>');
						echo('
						</div>
						</div>
						
				</div>');
				$this->display_nav(20);
			}
			function display_nav($n){
				$button=new input_button();
				echo('
				<div class="well well-lg  col-md-4">
				<div class="timer" id="timer">25:00</div>
				<div class="navigation">');
				for($i=1;$i<=$n;$i++){
					if($_SESSION['question_flag'.$i]==0)
					{
						if($i==$_SESSION['pointer']){
							$button->display("selected","navopt","submit","navbtn","",$i);
						}
						else{
							$button->display("","navopt","submit","navbtn","",$i);
						}
					}
					else{
						if($i==$_SESSION['pointer']){
							$button->display("selected","navopt flagged","submit","navbtn","",$i);
						}
						else{
							$button->display("","navopt flagged","submit","navbtn","",$i);
						}
						
					}
					
				}
				echo('</div>');
				$button->display_btn("khatam","next remove flash","submit","submit","",'SUBMIT AND FINISH QUIZ <i class="glyphicon glyphicon-arrow-right" id="right"></i>');	//show submit button
				echo('
				</div>
			</div>
			</form>
			<script>
			startTimer();
			</script>');
			}
		
			function flag()
			{
				if(isset($_POST['flag']))
				{
					$f=0;
					for($i=1;$i<=20;$i++)
					{
						if($_SESSION['question_flag'.$_SESSION['pointer']]==1)
						{
							$_SESSION['question_flag'.$_SESSION['pointer']]=0;
							$f=1;
							break;
						}
					}
					if($f==0)
					{
						$_SESSION['question_flag'.$_SESSION['pointer']]=1;
					}
				}
				
				for($i=1;$i<=20;$i++)
				{
					if($_SESSION['question_flag'.$i]==1)
					{	
						echo "flagged condition";
						echo "<div> This is the div tag for the flags.</div>";// Use value of $_SESSION['question_flag'.$_SESSION['pointer']] here.
					}
					else
					{
						echo "unflagged condition";
					}
					
				}
			}
}
class registration
{		
	function gen_password()
	{
		$arr=array("2","0","1","7");
		$d=new DateTime();       
		return ("SCR".substr($d->getTimeStamp(),7,10).$arr[rand(0,3)]);
	}
	
	function accept_form($conn)
	{
		require_once("alert.php");
		if(isset($_POST['register']))
		{
			$name=$_POST['name'];		// USE input_check() FOR SAFETY FROM SQL INJECTION
			$father_name=$_POST['fathersname'];
			$dob=$_POST['dob'];
			$phone_no=$_POST['mobile'];
			$email=$_POST['email'];
			$address=$_POST['address'];
			$city=$_POST['city'];
			$pincode=$_POST['pincode'];
			$college_flag_receive=$_POST['institute_type'];
			//echo ($college_flag_receive);
			if($college_flag_receive=="college")
			{
				$college_flag=1;
				$stream='N/A';
			}
			else if($college_flag_receive=="school")
			{
				$college_flag=0;
				$stream=$_POST['stream'];
			}
			$name_of_institution=$_POST['institute_name'];
			if($college_flag==1)
			{
				$standard=0; //meaning in college
			}
			else
			{
				$standard=$_POST['standard'];
			}
			
			$gender=$_POST['gender'];
				
			$check_query="SELECT email_id FROM users where email_id='$email'";		//REMOVE UNIQUE FROM phone_no from user_details table
			$check_query_run=mysqli_query($conn,$check_query);
			if(mysqli_num_rows($check_query_run)==0) //mysqli_fetch_assoc USE KARNA HAI
			{
				$send_pass=$this->gen_password(); // md5 password to be stored in database
				$password=md5($send_pass);
				$create_user_query="INSERT INTO users (email_id, password ) VALUES('$email','$password')";
				//echo($create_user_query.'$create_user_query=INSERT INTO users (email_id, password ) VALUES($email,$password)');
				$create_user_query_run=mysqli_query($conn,$create_user_query);
				if($create_user_query_run==TRUE)
				{
					$reg_id_query="SELECT reg_id FROM users WHERE email_id='$email'"; //SINCE email IS UNIQUE
					$reg_id_query_run=mysqli_query($conn,$reg_id_query);
					$reg_id_query_result=mysqli_fetch_assoc($reg_id_query_run);
					
					$reg_id=$reg_id_query_result['reg_id'];
					//echo($reg_id);
					$insert_query="INSERT INTO user_detail (reg_id,name,dob,gender,father_name,phone_no,address,pincode,city,standard,stream,name_of_institution,college_flag) VALUES($reg_id,'$name','$dob','$gender','$father_name','$phone_no','$address',$pincode,'$city',$standard,'$stream','$name_of_institution',$college_flag)";
					$insert_query_run=mysqli_query($conn,$insert_query);
					if($insert_query_run==TRUE)
					{
						//$forward_mail = new send_mail();
						//$forward_mail->execute($email,$name,$send_pass);
						require('sending_mail.php');
						//SEND the MAIL to the USER about the password
					}
				}
				
				else
				{
					$alert=new alert();
					$alert->exec("Unable to complete registration!","danger","101","suas.quizwiz2017@gmail.com");
				}
				
			}
			else
			{
				$alert=new alert();
				$alert->exec("Email Id is already registered!","danger","102","suas.quizwiz2017@gmail.com");
			}
		}
	}
}




?>