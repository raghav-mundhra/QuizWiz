<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="front_styles.css">
<link href="https://fonts.googleapis.com/css?family=Cabin|Exo+2|Kanit|Muli|Open+Sans|Raleway|Roboto" rel="stylesheet">
<link rel="stylesheet" href="slide.css">
<script>
        window.onload=function(){
            plusDivs(1);         
        }
    window.setInterval(function(){
        plusDivs(1);
    },3000);
    var slideIndex = 1;
    showDivs(slideIndex);
    
    function plusDivs(n) {
      showDivs(slideIndex += n);
    }
    
    function showDivs(n) {
      var i;
      var x = document.getElementsByClassName("mySlides");
      if (n > x.length) {slideIndex = 1}    
      if (n < 1) {slideIndex = x.length}
      for (i = 0; i < x.length; i++) {
         x[i].style.display = "none";  
      }
      x[slideIndex-1].style.display = "block";  
    }
    </script>
<?php
class head{
    var $title="Symbiosis University of Applied Sciences";
    var $logo="logo2.jpg";
    var $rtitle="QuizWiz";
    function displayheader(){
        echo(' <div class="container">
        <div class="logo"><a href="http://www.suas.ac.in" target="_blank"><img src="'.$this->logo.'" alt="Suas Indore"></a></div>
        <div class="title">'.$this->title.'</div>
        <div class="text">'.$this->rtitle.'</div>
        </div>);
    }
    function dispmenu($n,$href,$class,$tooltip){
        echo('<div class="menu-contain">
        <div class="menu">
        ');
        $i=0;
        foreach($class as $bclass){
            echo(' <div class="item"><a href="'.$href[$i].'"><i class="'.$bclass.'"></i><span style="font-size: 14px" id="menu_span">'.$tooltip[$i].'</span></a></div>');
            $i++;
        } 
        echo('    
        </div>
    </div>');
    }
    function displayheader_mail(){
        $show='<div class="mailcontainer">
        <div class="logo"><img src="'.$this->logo.'" alt="Suas Indore"></div>
        <div class="title">'.$this->title.'</div>
        <div class="text">'.$this->rtitle.'</div>
        </div>';
        return $show;
    }
}
class footer{
    function disp_footer(){
        echo('<div class="footer1">
                    <div class="uni_name1">
                        <a href="http://www.suas.ac.in" target="_blank">Symbiosis University of Applied Sciences</a>
                    </div>
                    <div class="copyright1">
                        &copy; '.date("Y").'
                    </div>
                    <div class="developers1">
                        <a href="developers.php" target="_blank">Developers</a>
                    </div>
                </div>');
    }
}
?>
