<?php 
session_start();
require_once('test_classes.php');
require_once('config.php');
$reg_backend = new registration();
$reg_backend->accept_form($conn);
$attempt = new attempt_now;
$attempt->execute($conn);
?>
<?php
require("preloader/preload.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>QuizWiz 2017</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="index_styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="shortcut icon" href="logo2.ico" />
      <link rel="stylesheet" href="css/style.css">
<script src="loader.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Cabin|Exo+2|Kanit|Muli|Open+Sans|Raleway|Roboto" rel="stylesheet">
    <script>
    function detect(){
        var std=document.getElementById("standard");
        if(document.getElementById("sch").checked){
            std.innerHTML=`<td><label for="">Standard</td>
                        <td><select name="standard" id="">
                        <option value="11">11</option>
                        <option value="12">12</option>   
                        </select></td>`;
        }
        else{
            std.innerHTML="";
        }

        if(document.getElementById("sch").checked){
            document.getElementById("schstream").innerHTML=`
            <td><label for="">Stream</td>
                                <td><select name="stream" id="">
                                <option value="Commerce">Commerce</option>
                                <option value="Science">Science</option>    
                                <option value="Humanities">Humanities</option>
                            </select></td>`;
        }
        else{
            document.getElementById("schstream").innerHTML="";
        }
                
    }
    </script>
</head>
<body>

    <?php
    require("frontend_lib.php");
    $head=new head();
    $head->displayheader();
    $footer=new footer();
    $footer->disp_footer();
    
    ?>
    <div class="img"></div>
    <div class="pcontain">
        <div class="name">
            Quiz Wiz 2017
        </div>
        <div class="button">

        <?php
        $var=date("d");
        $var2=(int)$var;
        if($var2<=24)
        {
            echo('<button type="submit" class="btnmain" onclick="openover()">Register for Quiz <i class="glyphicon glyphicon-edit"></i></button>
            ');        
        }
        else{
            echo('<button type="submit" class="btnmain" id="disabled">Register for Quiz <i class="glyphicon glyphicon-edit"></i></button>
            ');
        }
        ?>
            <?php 
            if($var2<=24)
            {
                echo('<button type="submit" class="btnmain" onclick="openover1()">
                Attempt Quiz Now <i class="glyphicon glyphicon-play-circle"></i></button>');   
                
            }
            else{
                echo('<button type="submit" class="btnmain"  id="disabled">
                Attempt Quiz Now <i class="glyphicon glyphicon-play-circle"></i></button>'); 
            }
            ?>
            
            <div class="dateinfo">Last date for Registration is 24<sup>th</sup> November</div>
            <div class="dateinfo1">Attempt quiz anytime on or before 24<sup>th</sup> November</div>
        </div>
    </div>
    <div class="overlay" id="overlay">
    <span class="btnclose" onclick="closeover()">&times;</span>
    <div class="overlaycontainer">
        <div class="qtitle">Quiz Registration</div>
        <form action="" method="post" class="col-md-4">
            <fieldset>
                <table>
                     <tr>
                        <td><label for="">Name </label></td>
                        <td><input type="text" name="name" ></td>
                    </tr>
                    <tr>
                        <td><label for="">Father's Name </td>
                        <td><input type="text" name="fathersname" ></td>
                    </tr>
                    <tr>
                        <td><label for="">Date of Birth</td>
                        <td><input type="date" name="dob" value="1/1/01" required><br><br></td>
                    </tr>
                    <tr>
                        <td> <label for="">Mobile Number</td>
                        <td><input type="number" name="mobile" min="7000000000" max="9999999999" required></td>
                    </tr>
                    <tr>
                        <td><label for="">E-mail </td>
                        <td><input type="email" name="email" id="email" required></td>
                    </tr>
                    <tr>
                        <td><label for="">Address</td>
                        <td><textarea name="address" rows="3" cols="30" required></textarea></td>
                    </tr>
                    <tr>
                        <td><label for="">City</td>
                        <td><input type="text" name="city" required></td>
                    </tr>
                    <tr>
                        <td><label for="">Institute Type</td>
                        <td style="color:white"> <span id="radiospan"> <input type="radio" name="institute_type" value="school"  onchange="detect()" id="sch"> School</span>
                        <span id="radiospan"><input type="radio" name="institute_type" value="college" onchange="detect()" id="clg" checked> College/University </span></td>
                    </tr>
                    <tr>
                        <td><label for="">
                            Institute Name
                        </td>
                        <td>
                            <input type="text" name="institute_name" required>
                        </td>
                    </tr>
                    
                    <tr id="standard">
                        
                    </tr>
                        <tr id="schstream">
                            
                        </tr>
                    <tr>
                        <td><label for="">PIN Code </td>
                        <td><input type="number" name="pincode" required></td>
                    </tr>
                    <tr>
                        <td><label for="">Gender</td>                            
                                <td style="color:white"><span id="radiospan"> <input type="radio" name="gender" value="M" checked> Male
                                <span id="radiospan"> <input type="radio" name="gender" value="F"> Female
                                <span id="radiospan"> <input type="radio" name="gender" value="O"> Others</td>
                    </tr>
                    
                    <tr style="text-align:center; margin-bottom: 20px">
                        <td colspan="2">
                            <button type="submit" name="register">Submit</button>
                            <button type="reset">Reset</button>
                        </td>
                    </tr>
                </table>
            </fieldset>
        </form>
    </div>
    </div>
        </div>
        <div class="overlay1" id="overlay1">
    <span class="btnclose" onclick="closeover1()">&times;</span>
    <div class="overlaycontainer1">
        <div class="qtitle1">Sign In for Attempting Quiz</div>
        <form action="" method="post" class="col-md-4" >
            <fieldset>
                <table>
                    <tr>
                        <td class="usersign"><label for=""  class="usersign">User Name </label></td>
                        <td><input type="text" name="email" ></td>
                    </tr>
                    <tr>
                        <td><label for=""  class="usersign">Password </label></td>
                        <td><input type="password" name="password" ></td>
                    </tr>
                    <tr style="text-align:center; margin-bottom: 20px">
                        <td colspan="2">
                            <button type="submit" class="signin" name="attempt_now">Attempt Now >></button> <!-- CHANGE THIS TO ATTEMPT NOW // USE input_button FORM -->
                        </td>
                    </tr>
                </table>
            </fieldset>
        </form>
    </div>
    </div>
        </div>

       
</body>
<script>
    function openover(){
            var o=document.getElementById("overlay");
            o.style.display="flex";
            
        }
        function closeover(){
            var o=document.getElementById("overlay");
            o.style.display="none";
        }
        function openover1(){
            var o=document.getElementById("overlay1");
            o.style.display="flex";
            
        }
        function closeover1(){
            var o=document.getElementById("overlay1");
            o.style.display="none";
        }
</script>
</html>
