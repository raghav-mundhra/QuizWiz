<?php
class alert{
    function exec($msg,$class,$err_no,$email){
        echo('<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>');       
        echo(' <div class="alert alert-'.$class.' fade in" id="err" style="font-size:20px; position:absolute; top:75px;z-index:101 !important; font-weight:bolder; width:100%">'.$msg."<br>ERROR CODE ".$err_no.": For further details please contact our technical support (".$email.") for further assistance".'<span class="close" data-dismiss="alert" style="font-size:2.6rem">&times</span></div>');
    }
    function success_exec($msg,$class){
        echo('<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>');
        echo(' <div class="alert alert-'.$class.' fade in" id="err" style="font-size:20px;position:absolute; top:75px; z-index:101 !important; font-weight:bolder; width:100%">'.$msg. '<span class="close" data-dismiss="alert" style="font-size:2.6rem">&times</span></div>');        
    }
} 
?>